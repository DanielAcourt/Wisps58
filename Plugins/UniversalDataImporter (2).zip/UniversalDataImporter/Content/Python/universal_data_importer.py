# Copyright (c) 2026 Sovereign Framework Architecture Team. All rights reserved.
# Universal Data Importer: Agnostic Schema Parser
"""
Agnostic JSON Schema Parser for Unreal Engine 5.8+ Universal Data Importer.
Validates, loads, and normalizes mapping schema configurations without project dependencies.
"""

import os
import json


class MappingPropertyRule:
    def __init__(
        self,
        csv_column,
        target_property,
        property_type="String",
        fallback_value=None,
        delimiter=",",
        extra_meta=None,
    ):
        self.csv_column = str(csv_column).strip()
        self.target_property = str(target_property).strip()
        self.property_type = str(property_type).strip()
        self.fallback_value = fallback_value
        self.delimiter = delimiter
        self.extra_meta = dict(extra_meta) if isinstance(extra_meta, dict) else {}


class ComponentPropertyRule:
    def __init__(self, component_class, csv_column, target_property, property_type="String", fallback_value=None):
        self.component_class = str(component_class).strip()
        self.csv_column = str(csv_column).strip()
        self.target_property = str(target_property).strip()
        self.property_type = str(property_type).strip()
        self.fallback_value = fallback_value


class ImporterSchema:
    def __init__(self):
        self.schema_version = "1.0.0"
        self.plugin_name = "UniversalDataImporter"
        self.target_data_asset_class = "/Script/Engine.DataAsset"
        self.target_package_directory = "/Game/Data/GeneratedAssets"
        self.auto_bind_art_assets = True
        self.art_search_directories = ["/Game/Assets/External", "/Game/ArtVault", "/Game/Assets"]
        self.column_to_property_map = []
        self.nested_component_property_map = []
        self.b_create_missing_blueprints = True
        self.default_parent_class = "/Script/Engine.Actor"
        self.parent_class_column = "ParentClass"
        self.cdo_binding_property = "DataAssetRef"
        self.default_input_mapping_context = ""

    @classmethod
    def load_from_json(cls, schema_filepath):
        """Loads and parses a JSON schema file, returning an ImporterSchema instance."""
        schema = cls()
        if not schema_filepath or not os.path.exists(schema_filepath):
            print(f"⚠️ [SchemaParser] Schema file not found at path: {schema_filepath}. Using defaults.")
            return schema

        try:
            with open(schema_filepath, "r", encoding="utf-8") as f:
                data = json.load(f)

            schema.schema_version = data.get("SchemaVersion", "1.0.0")
            schema.plugin_name = data.get("PluginName", "UniversalDataImporter")
            schema.target_data_asset_class = data.get("TargetDataAssetClass", "/Script/Engine.DataAsset")
            schema.target_package_directory = data.get("TargetPackageDirectory", "/Game/Data/GeneratedAssets")
            schema.auto_bind_art_assets = bool(data.get("AutoBindArtAssets", True))
            schema.art_search_directories = data.get("ArtSearchDirectories", ["/Game/Assets/External", "/Game/Assets"])

            known_rule_keys = {"CSVColumn", "TargetProperty", "PropertyType", "FallbackValue", "Delimiter"}
            schema.column_to_property_map = []
            for item in data.get("ColumnToPropertyMap", []):
                extra = {k: v for k, v in item.items() if k not in known_rule_keys}
                rule = MappingPropertyRule(
                    csv_column=item.get("CSVColumn", ""),
                    target_property=item.get("TargetProperty", ""),
                    property_type=item.get("PropertyType", "String"),
                    fallback_value=item.get("FallbackValue", None),
                    delimiter=item.get("Delimiter", ","),
                    extra_meta=extra,
                )
                if rule.csv_column and rule.target_property:
                    schema.column_to_property_map.append(rule)

            schema.nested_component_property_map = []
            for item in data.get("NestedComponentPropertyMap", []):
                rule = ComponentPropertyRule(
                    component_class=item.get("ComponentClass", "/Script/Engine.ActorComponent"),
                    csv_column=item.get("CSVColumn", ""),
                    target_property=item.get("TargetProperty", ""),
                    property_type=item.get("PropertyType", "String"),
                    fallback_value=item.get("FallbackValue", None),
                )
                if rule.csv_column and rule.target_property:
                    schema.nested_component_property_map.append(rule)

            bp_rules = data.get("BlueprintSynthesisRules", {})
            schema.b_create_missing_blueprints = bool(bp_rules.get("bCreateMissingBlueprints", True))
            schema.default_parent_class = bp_rules.get("DefaultParentClass", "/Script/Engine.Actor")
            schema.parent_class_column = bp_rules.get("ParentClassColumn", "ParentClass")
            schema.cdo_binding_property = bp_rules.get("CDOBindingProperty", "DataAssetRef")
            schema.default_input_mapping_context = bp_rules.get("DefaultInputMappingContext", "")

            print(
                f"✅ [SchemaParser] Successfully loaded schema '{schema_filepath}' "
                f"({len(schema.column_to_property_map)} column rules, {len(schema.nested_component_property_map)} component rules)"
            )
            return schema

        except Exception as e:
            print(f"❌ [SchemaParser] Failed to parse schema file '{schema_filepath}': {e}")
            return schema
```[cite: 2, 3]

---

#### B. `Plugins/UniversalDataImporter/Content/Python/universal_data_importer.py`
Full script including your original property types, art auto-binding, Blueprint synthesis, and reverse class exporter, plus `Enum`, `SkillArrayByTag`, and `EncounterSlots` support[cite: 1, 2, 3].

```python
# Copyright (c) 2026 Sovereign Framework Architecture Team. All rights reserved.
# Universal Data Importer Engine & Reverse Class Exporter
"""
Agnostic CSV Importer & Class-to-CSV Template Generator for Unreal Engine 5.8+.
Provides schema-driven data asset generation, blueprint synthesis, component attribute injection,
and reverse reflection to generate CSV templates and schema mappings from any UClass.
"""

import os
import csv
import sys
import json
from pathlib import Path

# Import schema parser
current_dir = Path(__file__).resolve().parent
if str(current_dir) not in sys.path:
    sys.path.insert(0, str(current_dir))

import schema_parser

try:
    import unreal
    IN_UNREAL = True
except ImportError:
    IN_UNREAL = False


def _resolve_enum_value(enum_class_path, raw_val):
    """Resolves an enum integer value from a UEnum path and member name/display name."""
    if not IN_UNREAL or not enum_class_path or raw_val is None:
        return None

    clean_val = str(raw_val).strip()
    if not clean_val:
        return None

    if "::" in clean_val:
        clean_val = clean_val.split("::")[-1].strip()

    enum_obj = unreal.load_object(None, enum_class_path)
    if not enum_obj:
        return None

    num_entries = enum_obj.num_enums()
    for idx in range(num_entries):
        name_str = str(enum_obj.get_name_string_by_index(idx))
        if name_str.endswith("_MAX"):
            continue
        short_name = name_str.split("::")[-1] if "::" in name_str else name_str
        display_name = str(enum_obj.get_display_name_text_by_index(idx))

        if (
            short_name.lower() == clean_val.lower()
            or name_str.lower() == clean_val.lower()
            or display_name.lower() == clean_val.lower()
        ):
            return int(enum_obj.get_value_by_index(idx))

    return None


def _resolve_skill_soft_refs(raw_val, delimiter=",", search_paths=None):
    """Resolves comma-separated Skill GameplayTags or asset names into SovereignSkillDefinition assets."""
    if not IN_UNREAL or not raw_val:
        return []

    if not search_paths:
        search_paths = ["/Game/Data/GeneratedCombat/Skills", "/Game/Data", "/Game"]

    tokens = [t.strip() for t in str(raw_val).split(delimiter) if t.strip()]
    if not tokens:
        return []

    skill_assets = []
    try:
        ar = unreal.AssetRegistryHelpers.get_asset_registry()
        for spath in search_paths:
            if unreal.EditorAssetLibrary.does_directory_exist(spath):
                assets = ar.get_assets_by_path(unreal.Name(spath), recursive=True)
                for ad in assets:
                    obj = unreal.EditorAssetLibrary.load_asset(str(ad.package_name))
                    if obj and obj.get_class().get_name() == "SovereignSkillDefinition":
                        skill_assets.append(obj)
    except Exception:
        pass

    resolved = []
    for token in tokens:
        matched_asset = None
        for sk in skill_assets:
            try:
                sk_tag = sk.get_editor_property("skill_tag")
                if str(sk_tag.tag_name) == token or str(sk.get_name()).lower() == token.lower():
                    matched_asset = sk
                    break
            except Exception:
                pass

        if not matched_asset:
            sanitized = token.replace(".", "_")
            candidates = [token, sanitized, f"DA_{sanitized}"]
            for spath in search_paths:
                for cand in candidates:
                    full_path = f"{spath}/{cand}"
                    if unreal.EditorAssetLibrary.does_asset_exist(full_path):
                        matched_asset = unreal.EditorAssetLibrary.load_asset(full_path)
                        break
                if matched_asset:
                    break

        if matched_asset:
            resolved.append(matched_asset)
        else:
            unreal.log_warning(f"⚠️ [UniversalImporter] Could not resolve SovereignSkillDefinition for '{token}'.")

    return resolved


def _build_encounter_slots(raw_val, delimiter=";", enemy_dir="/Game/Data/GeneratedCombat/Enemies"):
    """Parses 'SlotIndex:EnemyAssetName' entries separated by delimiter into FSovereignEncounterSlot structs."""
    if not IN_UNREAL or not raw_val:
        return []

    slots_out = []
    entries = [e.strip() for e in str(raw_val).split(delimiter) if e.strip()]

    for entry in entries:
        if ":" not in entry:
            unreal.log_warning(f"⚠️ [UniversalImporter] Malformed EnemySlots entry '{entry}' (expected 'SlotIndex:EnemyAssetName').")
            continue

        slot_str, enemy_name = entry.split(":", 1)
        slot_str = slot_str.strip()
        enemy_name = enemy_name.strip().replace(".", "_")

        try:
            slot_idx = int(slot_str)
        except ValueError:
            unreal.log_warning(f"⚠️ [UniversalImporter] Invalid slot index '{slot_str}' in '{entry}'.")
            continue

        enemy_path = f"{enemy_dir}/{enemy_name}"
        enemy_asset = None
        if unreal.EditorAssetLibrary.does_asset_exist(enemy_path):
            enemy_asset = unreal.EditorAssetLibrary.load_asset(enemy_path)
        else:
            unreal.log_warning(f"⚠️ [UniversalImporter] Enemy asset not found at '{enemy_path}' for slot {slot_idx}.")

        slot_struct = unreal.SovereignEncounterSlot()
        slot_struct.set_editor_property("slot_index", slot_idx)
        if enemy_asset:
            slot_struct.set_editor_property("enemy_definition", enemy_asset)

        slots_out.append(slot_struct)

    return slots_out


def apply_property_value(target_obj, prop_name, raw_val, prop_type="String", delimiter=",", extra_meta=None):
    """
    Reflectively sets prop_name on target_obj using prop_type type coercion.
    """
    if not target_obj or not prop_name or raw_val is None:
        return False

    val_str = str(raw_val).strip()
    extra_meta = extra_meta or {}

    try:
        if prop_type.lower() in ["string", "str"]:
            target_obj.set_editor_property(prop_name, val_str)
            return True

        elif prop_type.lower() in ["text"]:
            try:
                target_obj.set_editor_property(prop_name, unreal.TextLibrary.conv_string_to_text(val_str))
            except Exception:
                target_obj.set_editor_property(prop_name, val_str)
            return True

        elif prop_type.lower() in ["int", "int32", "integer"]:
            target_obj.set_editor_property(prop_name, int(float(val_str if val_str else "0")))
            return True

        elif prop_type.lower() in ["float", "double"]:
            target_obj.set_editor_property(prop_name, float(val_str if val_str else "0.0"))
            return True

        elif prop_type.lower() in ["bool", "boolean"]:
            target_obj.set_editor_property(prop_name, val_str.lower() in ["true", "1", "yes"])
            return True

        elif prop_type.lower() in ["enum"]:
            enum_path = extra_meta.get("EnumClass", "")
            enum_val = _resolve_enum_value(enum_path, val_str)
            if enum_val is not None:
                target_obj.set_editor_property(prop_name, enum_val)
                return True
            else:
                unreal.log_warning(f"⚠️ [UniversalImporter] Could not resolve enum '{val_str}' ({enum_path}) for '{prop_name}'.")

        elif prop_type.lower() in ["skillarraybytag", "skillarray"]:
            search_paths = extra_meta.get("SkillSearchPaths", None)
            skill_refs = _resolve_skill_soft_refs(val_str, delimiter=delimiter, search_paths=search_paths)
            target_obj.set_editor_property(prop_name, skill_refs)
            return True

        elif prop_type.lower() in ["encounterslots"]:
            enemy_dir = extra_meta.get("EnemyAssetDirectory", "/Game/Data/GeneratedCombat/Enemies")
            slot_structs = _build_encounter_slots(val_str, delimiter=delimiter, enemy_dir=enemy_dir)
            target_obj.set_editor_property(prop_name, slot_structs)
            return True

        elif prop_type.lower() in ["gameplaytag", "tag"]:
            if val_str and val_str.lower() != "none":
                gt = None
                try:
                    gt = unreal.GameplayTagsManager.get_gameplay_tags_manager().request_gameplay_tag(unreal.Name(val_str))
                except Exception:
                    try:
                        gt = unreal.GameplayTag()
                    except Exception:
                        pass
                if gt:
                    target_obj.set_editor_property(prop_name, gt)
                    return True

        elif prop_type.lower() in ["gameplaytagcontainer", "tagcontainer"]:
            if val_str:
                tags = [t.strip() for t in val_str.split(delimiter) if t.strip()]
                gt_list = []
                for t in tags:
                    try:
                        gt = unreal.GameplayTagsManager.get_gameplay_tags_manager().request_gameplay_tag(unreal.Name(t))
                        gt_list.append(gt)
                    except Exception:
                        try:
                            gt = unreal.GameplayTag()
                            gt_list.append(gt)
                        except Exception:
                            pass

                tag_container = unreal.GameplayTagContainer(gameplay_tags=gt_list)
                target_obj.set_editor_property(prop_name, tag_container)
                return True

        elif prop_type.lower() in ["softclasspath", "class"]:
            if val_str:
                loaded_cls = unreal.load_class(None, val_str)
                if loaded_cls:
                    target_obj.set_editor_property(prop_name, loaded_cls)
                    return True

        elif prop_type.lower() in ["staticmesh", "mesh"]:
            if val_str and IN_UNREAL and unreal.EditorAssetLibrary.does_asset_exist(val_str):
                mesh_obj = unreal.EditorAssetLibrary.load_asset(val_str)
                if mesh_obj and isinstance(mesh_obj, unreal.StaticMesh):
                    target_obj.set_editor_property(prop_name, mesh_obj)
                    return True

        elif prop_type.lower() in ["skeletalmesh"]:
            if val_str and IN_UNREAL and unreal.EditorAssetLibrary.does_asset_exist(val_str):
                sk_obj = unreal.EditorAssetLibrary.load_asset(val_str)
                if sk_obj and isinstance(sk_obj, unreal.SkeletalMesh):
                    target_obj.set_editor_property(prop_name, sk_obj)
                    return True

        elif prop_type.lower() in ["material", "materialinterface"]:
            if val_str and IN_UNREAL and unreal.EditorAssetLibrary.does_asset_exist(val_str):
                mat_obj = unreal.EditorAssetLibrary.load_asset(val_str)
                if mat_obj and isinstance(mat_obj, unreal.MaterialInterface):
                    target_obj.set_editor_property(prop_name, mat_obj)
                    return True

        elif prop_type.lower() in ["texture", "texture2D"]:
            if val_str and IN_UNREAL and unreal.EditorAssetLibrary.does_asset_exist(val_str):
                tex_obj = unreal.EditorAssetLibrary.load_asset(val_str)
                if tex_obj and isinstance(tex_obj, unreal.Texture2D):
                    target_obj.set_editor_property(prop_name, tex_obj)
                    return True

        elif prop_type.lower() in ["softobjectpath", "object"]:
            if val_str and IN_UNREAL and unreal.EditorAssetLibrary.does_asset_exist(val_str):
                loaded_obj = unreal.EditorAssetLibrary.load_asset(val_str)
                if loaded_obj:
                    target_obj.set_editor_property(prop_name, loaded_obj)
                    return True

    except Exception as e:
        if IN_UNREAL:
            unreal.log_warning(f"⚠️ [UniversalImporter] Reflection assignment warning for property '{prop_name}' ({prop_type}): {e}")
        else:
            print(f"⚠️ [UniversalImporter] Reflection assignment warning for property '{prop_name}': {e}")

    return False


def discover_and_bind_art_assets(data_asset, asset_name, schema, editor_asset_lib):
    """
    Automated Art Asset Discovery & Soft Pointer Auto-Binding.
    Scans schema.art_search_directories AND queries AssetRegistry globally for StaticMesh (SM_*),
    SkeletalMesh (SK_*), MaterialInterface (MI_* / M_*), and Texture2D (T_* / UI_*), binding soft object pointers.
    """
    if not IN_UNREAL or not data_asset or not schema.auto_bind_art_assets:
        return

    stripped_name = asset_name.replace("Sample_", "").replace("BP_", "").replace("Item_", "").replace("Species_", "").replace("Object_", "")
    clean_name = asset_name.replace(" ", "").replace("_", "")
    clean_stripped = stripped_name.replace(" ", "").replace("_", "")
    name_variants = list(dict.fromkeys([asset_name, stripped_name, clean_name, clean_stripped]))

    search_dirs = schema.art_search_directories

    # 1. Static Mesh (SM_<Variant> or <Variant>)
    b_found = False
    for sdir in search_dirs:
        if b_found:
            break
        for name_var in name_variants:
            if b_found:
                break
            for prefix in ["SM_", ""]:
                if b_found:
                    break
                sm_path = f"{sdir}/{prefix}{name_var}"
                if editor_asset_lib.does_asset_exist(sm_path):
                    sm_asset = editor_asset_lib.load_asset(sm_path)
                    if sm_asset and isinstance(sm_asset, unreal.StaticMesh):
                        for prop in ["mesh", "static_mesh", "stage_mesh"]:
                            try:
                                data_asset.set_editor_property(prop, sm_asset)
                                unreal.log(f"🎨 [UniversalImporter Auto-Art] Bound StaticMesh '{sm_path}' to property '{prop}' on '{asset_name}'")
                                b_found = True
                                break
                            except Exception:
                                pass

    if not b_found:
        try:
            ar = unreal.AssetRegistryHelpers.get_asset_registry()
            try:
                class_path = unreal.TopLevelAssetPath("/Script/Engine", "StaticMesh")
                assets = ar.get_assets_by_class(class_path, True)
            except Exception:
                try:
                    assets = ar.get_assets_by_class_name(unreal.Name("StaticMesh"), True)
                except Exception:
                    assets = ar.get_assets_by_class(unreal.Name("StaticMesh"), True)

            for asset_data in assets:
                aname = str(asset_data.asset_name)
                if any(aname == f"SM_{v}" or aname == v for v in name_variants):
                    sm_obj = editor_asset_lib.load_asset(str(asset_data.package_name))
                    if sm_obj and isinstance(sm_obj, unreal.StaticMesh):
                        for prop in ["mesh", "static_mesh", "stage_mesh"]:
                            try:
                                data_asset.set_editor_property(prop, sm_obj)
                                unreal.log(f"🎨 [UniversalImporter AssetRegistry] Found & Bound StaticMesh '{asset_data.package_name}' to property '{prop}' on '{asset_name}'")
                                b_found = True
                                break
                            except Exception:
                                pass
                        if b_found:
                            break
        except Exception:
            pass

    # 2. Skeletal Mesh (SK_<Variant> or <Variant>)
    b_found = False
    for sdir in search_dirs:
        if b_found:
            break
        for name_var in name_variants:
            if b_found:
                break
            for prefix in ["SK_", ""]:
                if b_found:
                    break
                sk_path = f"{sdir}/{prefix}{name_var}"
                if editor_asset_lib.does_asset_exist(sk_path):
                    sk_asset = editor_asset_lib.load_asset(sk_path)
                    if sk_asset and isinstance(sk_asset, unreal.SkeletalMesh):
                        for prop in ["skeletal_mesh", "stage_skeletal_mesh"]:
                            try:
                                data_asset.set_editor_property(prop, sk_asset)
                                unreal.log(f"🎨 [UniversalImporter Auto-Art] Bound SkeletalMesh '{sk_path}' to property '{prop}' on '{asset_name}'")
                                b_found = True
                                break
                            except Exception:
                                pass

    # 3. Material (MI_<Variant> or M_<Variant> or <Variant> or <Variant>_Mat or <Variant>_MI)
    b_found = False
    prefixes = ["MI_", "M_", "mi_", "m_", ""]
    suffixes = ["", "_MI", "_mi", "_Mat", "_mat", "_Material", "_material"]
    for sdir in search_dirs:
        if b_found:
            break
        for name_var in name_variants:
            if b_found:
                break
            for p in prefixes:
                if b_found:
                    break
                for s in suffixes:
                    if b_found:
                        break
                    mat_path = f"{sdir}/{p}{name_var}{s}"
                    if editor_asset_lib.does_asset_exist(mat_path):
                        mat_asset = editor_asset_lib.load_asset(mat_path)
                        if mat_asset and isinstance(mat_asset, unreal.MaterialInterface):
                            for prop in ["material", "species_material", "stage_material"]:
                                try:
                                    data_asset.set_editor_property(prop, mat_asset)
                                    unreal.log(f"🎨 [UniversalImporter Auto-Art] Bound Material '{mat_path}' to property '{prop}' on '{asset_name}'")
                                    b_found = True
                                    break
                                except Exception:
                                    pass

    if not b_found:
        try:
            ar = unreal.AssetRegistryHelpers.get_asset_registry()
            assets = []
            for cls_name in ["MaterialInstanceConstant", "MaterialInstanceDynamic", "Material"]:
                try:
                    class_path = unreal.TopLevelAssetPath("/Script/Engine", cls_name)
                    res = ar.get_assets_by_class(class_path, True)
                    if res:
                        assets.extend(res)
                except Exception:
                    try:
                        res = ar.get_assets_by_class_name(unreal.Name(cls_name), True)
                        if res:
                            assets.extend(res)
                    except Exception:
                        pass

            for asset_data in assets:
                aname = str(asset_data.asset_name).lower()
                for v in name_variants:
                    v_lower = v.lower()
                    if (
                        aname == v_lower
                        or aname == f"mi_{v_lower}"
                        or aname == f"m_{v_lower}"
                        or aname == f"{v_lower}_mi"
                        or aname == f"{v_lower}_mat"
                        or aname == f"{v_lower}_material"
                    ):
                        mat_obj = editor_asset_lib.load_asset(str(asset_data.package_name))
                        if mat_obj and isinstance(mat_obj, unreal.MaterialInterface):
                            for prop in ["material", "species_material", "stage_material"]:
                                try:
                                    data_asset.set_editor_property(prop, mat_obj)
                                    unreal.log(f"🎨 [UniversalImporter AssetRegistry] Found & Bound Material '{asset_data.package_name}' to property '{prop}' on '{asset_name}'")
                                    b_found = True
                                    break
                                except Exception:
                                    pass
                            if b_found:
                                break
                if b_found:
                    break
        except Exception:
            pass

    # 4. Texture / Icon (T_<Variant> or UI_<Variant> or <Variant>)
    b_found = False
    for sdir in search_dirs:
        if b_found:
            break
        for name_var in name_variants:
            if b_found:
                break
            for prefix in ["T_", "UI_", ""]:
                if b_found:
                    break
                tex_path = f"{sdir}/{prefix}{name_var}"
                if editor_asset_lib.does_asset_exist(tex_path):
                    tex_asset = editor_asset_lib.load_asset(tex_path)
                    if tex_asset and isinstance(tex_asset, unreal.Texture2D):
                        for prop in ["icon", "texture", "icon_texture"]:
                            try:
                                data_asset.set_editor_property(prop, tex_asset)
                                unreal.log(f"🎨 [UniversalImporter Auto-Art] Bound Texture2D '{tex_path}' to property '{prop}' on '{asset_name}'")
                                b_found = True
                                break
                            except Exception:
                                pass


def apply_component_properties(cdo, row, schema):
    """
    Reflectively traverses attached components on CDO and applies matching ComponentPropertyRules.
    """
    if not IN_UNREAL or not cdo or not schema.nested_component_property_map:
        return

    for rule in schema.nested_component_property_map:
        val = row.get(rule.csv_column, rule.fallback_value)
        if val is None:
            continue

        comp_cls = unreal.load_class(None, rule.component_class) if rule.component_class else None
        if not comp_cls:
            comp_cls = unreal.ActorComponent

        try:
            comps = cdo.get_components_by_class(comp_cls)
            for comp in comps:
                apply_property_value(comp, rule.target_property, val, rule.property_type)
        except Exception:
            pass


def synthesize_blueprint_actor(actor_class_str, parent_class_str, schema, data_asset, row, asset_tools, editor_asset_lib):
    """
    Synthesizes missing Blueprint actor asset if actor_class_str does not exist,
    binds the synthesized data_asset to the CDO, and injects component properties.
    """
    if not IN_UNREAL or not actor_class_str:
        return

    clean_path = actor_class_str.split(".")[0] if "." in actor_class_str else actor_class_str
    if clean_path.endswith("_C"):
        clean_path = clean_path[:-2]

    package_path, bp_name = os.path.split(clean_path)
    bp_asset = editor_asset_lib.load_asset(clean_path) if editor_asset_lib.does_asset_exist(clean_path) else None

    if not bp_asset and schema.b_create_missing_blueprints:
        parent_path = parent_class_str if parent_class_str else schema.default_parent_class
        parent_cls = unreal.load_class(None, parent_path)
        if not parent_cls:
            parent_cls = unreal.load_class(None, "/Script/Engine.Actor")

        if parent_cls:
            if not editor_asset_lib.does_directory_exist(package_path):
                editor_asset_lib.make_directory(package_path)

            factory = unreal.BlueprintFactory()
            factory.set_editor_property("parent_class", parent_cls)
            bp_asset = asset_tools.create_asset(bp_name, package_path, None, factory)
            if bp_asset:
                unreal.log(f"✨ [UniversalImporter] Synthesized missing Blueprint actor: '{clean_path}' (Parent: {parent_cls.get_name()})")

    if bp_asset:
        try:
            unreal.BlueprintEditorLibrary.compile_blueprint(bp_asset)
            gen_class = unreal.load_class(None, f"{clean_path}.{bp_name}_C")
            if gen_class:
                cdo = unreal.get_default_object(gen_class)
                if cdo:
                    if data_asset and schema.cdo_binding_property:
                        for prop in [schema.cdo_binding_property, "data_asset", "data_asset_ref", "species_data"]:
                            try:
                                cdo.set_editor_property(prop, data_asset)
                                unreal.log(f"🔗 [UniversalImporter] Bound DataAsset to CDO property '{prop}' on '{bp_name}'.")
                                break
                            except Exception:
                                pass

                    apply_component_properties(cdo, row, schema)

                cdo.modify()
                bp_asset.modify()
                unreal.BlueprintEditorLibrary.compile_blueprint(bp_asset)
                editor_asset_lib.save_loaded_asset(bp_asset)
        except Exception as e_bp:
            unreal.log_warning(f"⚠️ [UniversalImporter] Blueprint synthesis/CDO binding notice for '{bp_name}': {e_bp}")


def export_csv_template_from_class(class_path="/Script/UniversalDataImporter.UniversalDataAsset", output_csv_path="", output_schema_path=""):
    """
    Reflects ANY user UClass (DataAsset, Actor, or Component) and exports:
    1. A sample CSV template with headers for all editable UProperties.
    2. A matching JSON mapping schema.
    """
    if not IN_UNREAL:
        print("❌ [UniversalImporter] export_csv_template_from_class requires running inside Unreal Editor.")
        return False

    if not class_path or not str(class_path).strip():
        class_path = "/Script/UniversalDataImporter.UniversalDataAsset"

    uclass = unreal.load_class(None, class_path)
    if not uclass:
        unreal.log_warning(f"⚠️ Could not load class '{class_path}', falling back to '/Script/Engine.DataAsset'.")
        class_path = "/Script/Engine.DataAsset"
        uclass = unreal.load_class(None, class_path)

    if not uclass:
        unreal.log_error(f"❌ Could not load class at path '{class_path}'")
        return False

    if not output_csv_path or not str(output_csv_path).strip():
        output_csv_path = os.path.abspath(os.path.join(current_dir, "..", "..", "Resources", "SampleTemplates", "GeneratedTemplate.csv"))

    if not output_schema_path or not str(output_schema_path).strip():
        output_schema_path = os.path.abspath(os.path.join(current_dir, "..", "..", "Resources", "Schemas", "GeneratedSchema.json"))

    output_csv_path = str(output_csv_path).strip().strip("'").strip('"').replace("\\", "/")
    output_schema_path = str(output_schema_path).strip().strip("'").strip('"').replace("\\", "/")

    cdo = unreal.get_default_object(uclass)
    if not cdo:
        unreal.log_error(f"❌ Could not resolve CDO for class '{class_path}'")
        return False

    headers = ["Name", "ParentClass", "ActorClass"]
    schema_rules = [
        {"CSVColumn": "Name", "TargetProperty": "Name", "PropertyType": "String", "FallbackValue": "NewAsset"}
    ]

    for prop in dir(cdo):
        if prop.startswith("_") or prop in ["Name", "ParentClass", "ActorClass"]:
            continue
        try:
            val = cdo.get_editor_property(prop)
            headers.append(prop)
            ptype = "String"
            if isinstance(val, bool):
                ptype = "Bool"
            elif isinstance(val, int):
                ptype = "Int32"
            elif isinstance(val, float):
                ptype = "Float"
            elif isinstance(val, unreal.Text):
                ptype = "Text"

            schema_rules.append({
                "CSVColumn": prop,
                "TargetProperty": prop,
                "PropertyType": ptype,
                "FallbackValue": str(val) if val is not None else "",
            })
        except Exception:
            pass

    os.makedirs(os.path.dirname(os.path.abspath(output_csv_path)), exist_ok=True)
    with open(output_csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerow([f"Sample_{uclass.get_name()}_01", "/Script/Engine.Actor", ""] + [""] * (len(headers) - 3))

    schema_data = {
        "SchemaVersion": "1.0.0",
        "PluginName": "UniversalDataImporter",
        "TargetDataAssetClass": class_path,
        "TargetPackageDirectory": "/Game/Data/GeneratedAssets",
        "AutoBindArtAssets": True,
        "ArtSearchDirectories": [
            "/Game/Art/Meshes",
            "/Game/Art/SkeletalMeshes",
            "/Game/Art/Materials",
            "/Game/Art/Textures",
            "/Game/Art",
            "/UniversalDataImporter/Art/Meshes",
            "/UniversalDataImporter/Art/Materials",
            "/UniversalDataImporter/Art/Textures",
            "/Game/Assets/External",
            "/Game/Assets",
        ],
        "ColumnToPropertyMap": schema_rules,
        "NestedComponentPropertyMap": [],
        "BlueprintSynthesisRules": {
            "bCreateMissingBlueprints": True,
            "DefaultParentClass": "/Script/Engine.Actor",
            "ParentClassColumn": "ParentClass",
            "CDOBindingProperty": "DataAssetRef",
            "DefaultInputMappingContext": "",
        },
    }

    os.makedirs(os.path.dirname(os.path.abspath(output_schema_path)), exist_ok=True)
    with open(output_schema_path, "w", encoding="utf-8") as f:
        json.dump(schema_data, f, indent=2)

    unreal.log(f"✨ [UniversalImporter] Generated CSV template at '{output_csv_path}' and Schema at '{output_schema_path}' for class '{uclass.get_name()}'.")
    return True


def import_csv_with_schema(csv_path="", schema_path="", b_overwrite=True, b_auto_bind_art=True):
    """
    Main Agnostic Import Engine:
    Reads any CSV dataset using a JSON schema mapping, creating DataAssets and synthesizing Blueprints.
    """
    if not csv_path or not str(csv_path).strip() or not os.path.exists(str(csv_path).strip()):
        gen_csv = os.path.abspath(os.path.join(current_dir, "..", "..", "Resources", "SampleTemplates", "GeneratedTemplate.csv"))
        sample_csv = os.path.abspath(os.path.join(current_dir, "..", "..", "Resources", "SampleTemplates", "SampleSpeciesTemplate.csv"))
        if os.path.exists(gen_csv):
            csv_path = gen_csv
        elif os.path.exists(sample_csv):
            csv_path = sample_csv

    if not schema_path or not str(schema_path).strip() or not os.path.exists(str(schema_path).strip()):
        gen_schema = os.path.abspath(os.path.join(current_dir, "..", "..", "Resources", "Schemas", "GeneratedSchema.json"))
        default_schema = os.path.abspath(os.path.join(current_dir, "..", "..", "Resources", "Schemas", "DefaultMappingSchema.json"))
        if os.path.exists(gen_schema):
            schema_path = gen_schema
        elif os.path.exists(default_schema):
            schema_path = default_schema

    schema = schema_parser.ImporterSchema.load_from_json(schema_path)

    csv_path = str(csv_path).strip().strip("'").strip('"').replace("\\", "/")
    if not csv_path or not os.path.exists(csv_path):
        msg = f"❌ CSV file not found at path: '{csv_path}'. Run export_csv_template() first or pass a valid CSV path."
        if IN_UNREAL:
            unreal.log_error(msg)
        else:
            print(msg)
        return False

    rows = []
    with open(csv_path, mode="r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(r)

    print(f"🏛️ [UniversalImporter] Read {len(rows)} rows from CSV '{csv_path}'")

    if not IN_UNREAL:
        print("ℹ️ Running outside Unreal Editor context. Validation complete.")
        return True

    asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
    editor_asset_lib = unreal.EditorAssetLibrary

    target_dir = schema.target_package_directory
    if not editor_asset_lib.does_directory_exist(target_dir):
        editor_asset_lib.make_directory(target_dir)

    target_class = unreal.load_class(None, schema.target_data_asset_class)
    if not target_class:
        unreal.log_error(f"❌ Could not load target DataAsset class '{schema.target_data_asset_class}'")
        return False

    created_count = 0
    updated_count = 0

    for row in rows:
        asset_name = (
            row.get("Name")
            or row.get("EnemyTag")
            or row.get("EncounterTag")
            or row.get("ItemTag")
            or row.get("Tag")
            or ""
        ).strip().replace(".", "_")
        if not asset_name:
            continue

        asset_path = f"{target_dir}/{asset_name}"
        existing_asset = editor_asset_lib.load_asset(asset_path) if editor_asset_lib.does_asset_exist(asset_path) else None

        if existing_asset:
            if not b_overwrite:
                continue
            data_asset = existing_asset
            updated_count += 1
        else:
            factory = unreal.DataAssetFactory()
            factory.set_editor_property("data_asset_class", target_class)
            data_asset = asset_tools.create_asset(asset_name, target_dir, target_class, factory)
            created_count += 1

        if not data_asset:
            continue

        for rule in schema.column_to_property_map:
            val = row.get(rule.csv_column, rule.fallback_value)
            if val is not None:
                apply_property_value(
                    data_asset,
                    rule.target_property,
                    val,
                    rule.property_type,
                    rule.delimiter,
                    extra_meta=rule.extra_meta,
                )

        if b_auto_bind_art and schema.auto_bind_art_assets:
            discover_and_bind_art_assets(
                data_asset=data_asset,
                asset_name=asset_name,
                schema=schema,
                editor_asset_lib=editor_asset_lib,
            )

        editor_asset_lib.save_loaded_asset(data_asset)

        actor_class_str = row.get("ActorClass", "").strip()
        parent_class_str = row.get(schema.parent_class_column, "").strip()
        if actor_class_str:
            synthesize_blueprint_actor(
                actor_class_str=actor_class_str,
                parent_class_str=parent_class_str,
                schema=schema,
                data_asset=data_asset,
                row=row,
                asset_tools=asset_tools,
                editor_asset_lib=editor_asset_lib,
            )

    unreal.log(f"✅ [UniversalImporter] Complete! Created: {created_count} | Updated: {updated_count} assets in '{target_dir}'.")
    return True
```[cite: 1, 2, 3]