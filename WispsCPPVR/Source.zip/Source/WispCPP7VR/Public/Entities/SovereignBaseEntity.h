// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "SaveSystem/SovereignGameData.h"
#include "DataTables/SovereignSpeciesData.h"

#include "GameplayTagContainer.h"
#include "GameplayTagAssetInterface.h" 

#include "Interaction/SovereignEntityInterface.h"
#include "Interaction/SovereignInterfaceMain.h"

#include "SovereignBaseEntity.generated.h"

class USovereignSaveableEntityComponent;
class USovereignSpeciesData;
class UStaticMeshComponent;

/**
 * ASovereignBaseEntity: Base class for all possessable simulation entities.
 */
UCLASS()
class WISPCPP7VR_API ASovereignBaseEntity : public APawn, public IGameplayTagAssetInterface, public ISovereignEntityInterface, public IInteractionInterface
{
	GENERATED_BODY()

public:
	ASovereignBaseEntity();

	UFUNCTION(BlueprintCallable, Category = "Sovereign|Soul")
	USovereignSaveableEntityComponent* GetSaveDataComponent() const { return SaveDataComponent; }

	UFUNCTION(BlueprintCallable, Category = "Sovereign|Data")
	USovereignSpeciesData* GetSpeciesData() const { return SpeciesData; }

	UFUNCTION(BlueprintCallable, Category = "Sovereign|Growth")
	int32 GetCurrentGrowthStage() const { return CurrentGrowthStage; }

	/** Returns the unique Save System ID for this specific entity */
	UFUNCTION(BlueprintCallable, Category = "Sovereign|Entity")
	FGuid GetSovereignID() const;

	/** Flag indicating if this entity was restored from save data */
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Sovereign|SaveSystem")
	bool bIsLoadedEntity = false;

	UFUNCTION(BlueprintPure, Category = "Sovereign|SaveSystem")
	bool IsLoadedEntity() const;

	UFUNCTION(BlueprintCallable, Category = "Sovereign|SaveSystem")
	void SetIsLoadedEntity(bool bLoaded);

	UFUNCTION(BlueprintCallable, Category = "Sovereign|Input")
	class UInputMappingContext* GetDefaultMappingContext() const { return DefaultMappingContext; }

	UFUNCTION(BlueprintCallable, Category = "Sovereign|Input")
	class UInputAction* GetPossessAction() const { return PossessAction; }

	/** The Unique Identity Signature for this class. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Sovereign|Identity")
	FGameplayTag IdentitySignature;

	/** The core Name of the object **/ 
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sovereign|Identity")
	FString SpeciesName;


	/** The Gameplay Tags for this entity. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sovereign|Identity")
	FGameplayTagContainer GameplayTags;

	/** The Gameplay Tags that this Enity is checking against. */
	UFUNCTION(BlueprintCallable, Category = "Sovereign|Tags")
	void IngestSovereignTag(FString IncomingTagString);

	// --- IGameplayTagAssetInterface Implementation ---
	virtual void GetOwnedGameplayTags(FGameplayTagContainer& TagContainer) const override;

	// --- IInteractionInterface Implementation ---
	virtual class USovereignSaveableEntityComponent* GetSovereignSoul_Implementation() const override;
	virtual bool CanBePossessed_Implementation() override;
	virtual void RequestPossession_Implementation(AController* RequestingController) override;
	virtual USceneComponent* GetPossessionAttachmentComponent_Implementation() override;
	virtual AActor* GetInhabitingSpirit_Implementation() override;
	virtual void RequestSoulEject_Implementation() override;

	/** Handles unpossession/ejection trigger when F / Possession action is pressed on an inhabited vessel */
	UFUNCTION(BlueprintCallable, Category = "Sovereign|Possession")
	virtual void HandlePossessionLifecycle();

	// --- Lifecycle ---
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	virtual void PossessedBy(AController* NewController) override;
	virtual void UnPossessed() override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	/** Primary logic for moving from one growth stage to the next */
	virtual void Evolve();


	/** Called by the Spawn Manager after the actor has been spawned. */
	virtual void PostSpawnInitialize(const USovereignSpeciesData* InSpeciesData, const FGuid& InMotherID, const FGuid& InFatherID);

protected:
	/** Can this entity be possessed by a Sovereign Spirit? */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sovereign|Possession")
	bool bCanBePossessed = true;

	/** Calculates the float delay based on the UpdateFrequency enum */
	float GetHeartbeatInterval() const;

	// --- Components ---

	/** The physical body of the entity (The Oak Tree, the Bee, etc.) */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Sovereign|Visuals")
	UStaticMeshComponent* EntityMesh;

	/** The Soul of the Actor: Contains the GUID and Metadata tags */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Sovereign|SaveSystem")
	USovereignSaveableEntityComponent* SaveDataComponent;

	/** Array of 8 meshes representing the growth stages (0-7) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sovereign|Visuals")
	TArray<UStaticMesh*> GrowthMeshes;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sovereign|Security")
	int32 TrustSignature = 0;

	/** 1.0 is default size. 2.0 is double size. Allows for growth without new meshes. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sovereign|Growth")
	float VisualScale = 1.0f;

	/** Base health/stamina multiplier for this stage */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sovereign|Growth")
	float BaseConstitution = 1.0f;

	// --- Data & Evolution ---

	/** Logic to update the entity based on new Species Data */
	UFUNCTION(BlueprintCallable, Category = "Sovereign|Identity")
	virtual void InitializeFromSovereignData(USovereignSpeciesData* InData);


protected:
	void VerifySymmetryLevel();


	/** The 'Passport' for this entity's species and trust level */
	/** The "Advanced" data asset defining growth stages, health, and species attributes */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sovereign|Data", meta = (AllowPrivateAccess = "true"))
	class USovereignSpeciesData* SpeciesData;

	/** Which of the 8 growth stages are we currently in? (0 to 7) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sovereign|Growth")
	int32 CurrentGrowthStage = 0;

	/** How often this entity processes logic */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sovereign|Performance")
	EUpdateFrequency UpdateFrequency = EUpdateFrequency::Standard;

	/** Swaps the Static Mesh based on the current Growth Stage index */
	UFUNCTION(BlueprintCallable, Category = "Sovereign|Visuals")
	void RefreshVisuals();

	// --- Internal Logic ---

	/** Input Assets - Assign in Blueprint to bind Eject / Unpossession in C++ */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sovereign|Input")
	class UInputMappingContext* DefaultMappingContext;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sovereign|Input")
	class UInputAction* PossessAction;

	/** The recurring timer handle for the heartbeat logic */
	FTimerHandle HeartbeatTimerHandle;

	/** If true, the Soul uses the ManualBirthDate instead of the current time on first spawn */
	UPROPERTY(EditAnywhere, Category = "Sovereign|Identity")
	bool bUseManualBirthDate = false;

	/** Format: "2017.03.23-16.00.00" (Year.Month.Day-Hour.Minute.Second) */
	UPROPERTY(EditAnywhere, Category = "Sovereign|Identity", meta = (EditCondition = "bUseManualBirthDate"))
	FString ManualBirthDate = "2017.03.23-16.00.00";

	/** The logic function that runs growth progress and checks for Evolution */
	virtual void OnSovereignHeartbeat();

	//can i evolve?
	void CheckForEvolution();

	/** Callback function for when a mesh has been asynchronously loaded. */
	void OnMeshLoaded(TSoftObjectPtr<UStaticMesh> LoadedMeshPtr);

	/** Callback function for when a material has been asynchronously loaded. */
	void OnMaterialLoaded(TSoftObjectPtr<class UMaterialInterface> LoadedMaterialPtr);
};
