﻿// Fill out your copyright notice in the Description page of Project Settings.
// This is the Sovereign Spawn Utility responsibly for spawning new entities in the world. It uses the USovereignSpeciesData as a template to know what to spawn and how to initialize it.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "GameplayTagContainer.h" // <--- CRITICAL: Fixes FGameplayTag errors
#include "SovereignSpeciesData.generated.h"

class ASovereignBaseEntity;
class USkeletalMesh;

/** Curve type used to generate 8-stage D&D attribute scaling curves from Stage 0 defaults. */
UENUM(BlueprintType)
enum class ESovereignGrowthCurve : uint8
{
    Linear          UMETA(DisplayName = "Linear"),
    Exponential     UMETA(DisplayName = "Exponential"),
    FrontLoaded     UMETA(DisplayName = "Front-Loaded (S-Curve)"),
    Flat            UMETA(DisplayName = "Flat (Static)")
};

/** * The Unique Tag for this species (e.g., Species.Plant.Oak).
     * This is what the Save System looks for to know which asset to load.
     */
USTRUCT(BlueprintType)
struct FSovereignGrowthStage
{
    GENERATED_BODY()

    /** The 3D model for this specific stage */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sovereign|Growth")
    TSoftObjectPtr<UStaticMesh> StageMesh;

    /** Optional Skeletal Mesh for Character entities (e.g. Humanoids, Dragons) */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sovereign|Growth")
    TSoftObjectPtr<USkeletalMesh> StageSkeletalMesh;

    /** Optional Material override for this growth stage */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sovereign|Growth")
    TSoftObjectPtr<class UMaterialInterface> StageMaterial;

    /** NEW: Scaling factor for this stage (1.0 = Default) */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sovereign|Growth")
    float VisualScale = 1.0f;

    // PHYSICAL ATTRIBUTES (The 'Advanced' data)
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attributes")
    int32 BaseStrength = 10;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attributes")
    int32 BaseDexterity = 10;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attributes")
    int32 BaseConstitution = 10;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attributes")
    int32 BaseIntelligence = 10;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attributes")
    int32 BaseWisdom = 10;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attributes")
    int32 BaseCharisma = 10;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attributes")
    int32 BaseLuck = 10;

    // How much food/water/energy this stage consumes
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Attributes")
    float MetabolicRate = 1.0f;


};

/** * USovereignSpeciesData
 * The 'Template' for an entire species.
 */
UCLASS(BlueprintType)
class WISPCPP7VR_API USovereignSpeciesData : public UPrimaryDataAsset
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity")
    FText SpeciesName;

    /** * The Unique Tag for this species (e.g., Species.Plant.Oak).
     * This is the bridge to Isla's Save System [2025-12-20].
     */

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity")
    FGameplayTag SpeciesTag;


    /** * Flexible Trait Container: Allows for dynamic system discovery.
     * The Sovereign Soul checks this container to trigger specific behaviors.
     */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity|Traits")
    FGameplayTagContainer SpeciesTraits;

        /** * Dynamic Metadata Map: Handles the "unknown tag" requirement.
     * Use this for specialized species data that isn't hardcoded in the struct.
     */

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity|Metadata")
    TMap<FGameplayTag, float> DynamicAttributes;

    /** Growth curve model for generating growth stage stats */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Evolution")
    ESovereignGrowthCurve GrowthCurveType = ESovereignGrowthCurve::Exponential;

    /** Scale multiplier applied per growth stage (e.g., 1.20 = 20% increase per stage) */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Evolution")
    float GrowthScaleFactor = 1.20f;

    /** Target number of growth stages for this species (1 to 16, default 1) */
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Evolution", meta = (ClampMin = "1", ClampMax = "16"))
    int32 GrowthStageCount = 1;

    /** The growth stages array allocated dynamically based on GrowthStageCount */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Evolution")
    TArray<FSovereignGrowthStage> GrowthStages;

    /** The 8 growth stages (or however many you need) */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Evolution")
    TArray<FSovereignGrowthStage> MaxGrowthStages;

    /** Generates or recalculates the 8 growth stages based on Stage 0 attributes and GrowthCurveType */
    UFUNCTION(CallInEditor, Category = "Evolution")
    void GenerateGrowthStages();

#if WITH_EDITOR
    virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

    //Identity
    /** The Unique Identity Signature for this species. */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity")
    FGameplayTag IdentitySignature;


    //Movement

    /** Default movement mode (Flying for Bees, Stationary for Oak) */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Movement")
    bool bCanFly = false;

    /** Default movement mode (Flying for Bees, Stationary for Oak) */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Movement")
    bool bCanMove = false;

    /** Default movement mode (Flying for Bees, Stationary for Oak) */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Movement")
    bool bIsBiological = false;

    // --- SPIRITUAL & QI AURA FOOTPRINT [B-059] ---

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Qi Aura")
    float QiGive = 5.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Qi Aura")
    float QiTake = 5.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Qi Aura")
    float QiAuraRadius = 500.0f;

    /** Default Material assigned across all stages unless overridden in GrowthStages */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Visuals")
    TSoftObjectPtr<class UMaterialInterface> SpeciesMaterial;

    /** The Actor Class to spawn for this species. */
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Spawning")
    TSoftClassPtr<class AActor> ActorClass;

    // Entities are spawned and initialized in the game world using this data asset as a template.
    // The process involves several systems:
    //
    // 1. Define a Species in Unreal Editor
    //    └─ Create a USovereignSpeciesData asset
    //    └─ Set Species.Plant.Oak tag
    //    └─ Configure 8 growth stages with meshes & attributes
    //    └─ Set ActorClass to spawn
    //
    // 2. Save System Reference
    //    └─ When saving an entity, stores its SpeciesTag
    //    └─ When loading, queries SpeciesTag to find this asset
    //
    // 3. Sovereign Soul System
    //    └─ Queries SpeciesTraits for behaviors to enable
    //    └─ Reads DynamicAttributes for modular/unknown data
    //    └─ Uses current growth stage for visual & physical properties
    //
    // 4. Spawning/Initialization
    //    └─ Spawn system reads ActorClass
    //    └─ Instantiates ASovereignBaseEntity with this template
    //    └─ Sets initial growth stage, movement flags, attributes
};
