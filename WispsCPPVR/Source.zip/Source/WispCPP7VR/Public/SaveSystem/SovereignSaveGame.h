// Copyright (c) 2013-2026 Daniel Acourt. Version 36.4.1. Licensed under GPLv3 (See LICENSE). Last Updated: 2026-11-06

/*2. The SaveGame Object (UWispsSaveGame)
Class Type: Inherits from SaveGame

Location: Public/SaveSystem/ & Private/SaveSystem/

Purpose: This is the actual file format. It will contain a FGardenSaveData variable. It acts as the "Suitcase" that travels to the hard drive.
The Container: A standard Unreal class used to store high-level data like "Last Played Date" or "Player Level."
Image Tag:*/

#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "UObject/NoExportTypes.h"
#include "GameFramework/SaveGame.h"
#include "SaveSystem/SovereignGameData.h"
#include "SaveSystem/SovereignDungeonDelta.h"

#include "SovereignSaveGame.generated.h"

/**
 * 
 */USTRUCT(BlueprintType)
     struct FSovereignActorData
 {
     GENERATED_BODY()

     // The unique ID we generated in the Component
     UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sovereign")
     FGuid EntityID;

     // The custom object/display name (e.g., "Daniel")
     UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sovereign")
     FString ObjectName;

     UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sovereign")
	 FString EntityName;

     // The blueprint path so we can respawn this object if it's missing
     UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sovereign")
     FString ClassPath;

     // The "Unknown Tags" we harvested (e.g., "GrowthStage:5")
     UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sovereign")
     TMap<FString, FString> MetaTags;

     // The physical location/rotation in the world
     UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sovereign")
     FTransform Transform;
 };

 /**
  * @class USovereignSaveGame
  * @brief The "Suitcase" file that gets written to the hard drive.
  */
 UCLASS()
     class WISPCPP7VR_API USovereignSaveGame : public USaveGame
 {
     GENERATED_BODY()

 public:
     // The master list of every saved entity in the world
     UPROPERTY()
     TArray<FEntitySaveData> SavedActors; // <--- This must match the struct in SovereignGameData.h

     // High-level metadata (Optional but helpful for Isla)
     UPROPERTY(BlueprintReadWrite, Category = "Sovereign")
     FString SaveSlotName;

     UPROPERTY(BlueprintReadWrite, Category = "Sovereign")
     FDateTime SaveTime;

     /** Lightweight dungeon delta & seed state (Ticket B-115) */
     UPROPERTY(BlueprintReadWrite, Category = "Sovereign|Dungeon")
     FSovereignDungeonDeltaState DungeonDelta;

 };