// Fill out your copyright notice in the Description page of Project Settings.


#include "Components/SovereignAttributeComponent.h"
#include "Components/SovereignLevelComponent.h"
#include "Entities/SovereignBaseEntity.h"
#include "Entities/SovereignBaseCharacter.h"
#include "Entities/SovereignSaveableEntityComponent.h"
#include "Components/SovereignControllerComponent.h"
#include "DataTables/SovereignSpeciesData.h"
#include "SaveSystem/SovereignSaveManager.h"
#include "Combat/SovereignDungeonSubsystem.h"
#include "Engine/World.h"
#include "Engine/GameInstance.h"
#include "UObject/ConstructorHelpers.h"
#include "Blueprint/UserWidget.h"
#include "Dom/JsonObject.h"
#include "GameFramework/Actor.h"

USovereignAttributeComponent::USovereignAttributeComponent()
{
	PrimaryComponentTick.bCanEverTick = false;

	static ConstructorHelpers::FClassFinder<UUserWidget> AttrWidgetFinder(TEXT("/Game/Assets/UI/WBP_Attributes.WBP_Attributes_C"));
	if (AttrWidgetFinder.Succeeded())
	{
		InspectorWidgetClass = AttrWidgetFinder.Class;
	}

	// Default internal values to prevent crashes before sync
	Strength = 10;
	Dexterity = 10;

	Constitution = 10;
	Intelligence = 10;

	Wisdom = 10;
	Charisma = 10;

	Luck = 10;
	ArmourClass = 10;

	CurrentHealth = 1.0f;
	
	//moved to bio component
	//CurrentStamina = 1.0f;

	//DefaultDifficalty = 1.0f
}

void USovereignAttributeComponent::BeginPlay()
{
	Super::BeginPlay();

	// If we are in the middle of a dungeon expedition load or world state load,
	// do NOT initialize fresh stats on BeginPlay. Let OnLoad() handle it.
	if (IsLoadedCharacter())
	{
		UE_LOG(LogTemp, Log, TEXT("Sovereign: %s BeginPlay deferred stats init because load context is active."),
			GetOwner() ? *GetOwner()->GetName() : TEXT("Unknown"));
		return;
	}

	// Only sync species stats if this is truly a fresh spawn with no save pending
	SyncStatsFromEntity();

	// Start the fresh vessel at full health based on its new stats
	CurrentHealth = GetMaxHealth();
	MaxHealth = GetMaxHealth();
}

void USovereignAttributeComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

bool USovereignAttributeComponent::IsLoadedCharacter() const
{
	// 1. Direct component flag
	if (bIsLoadedFromSave)
	{
		return true;
	}

	if (AActor* Owner = GetOwner())
	{
		// 2. Owning Soul / SaveDataComponent
		if (USovereignSaveableEntityComponent* Soul = Owner->FindComponentByClass<USovereignSaveableEntityComponent>())
		{
			if (Soul->IsLoadedEntity())
			{
				return true;
			}
		}

		// 3. Owning Character / Entity
		if (ASovereignBaseCharacter* BaseChar = Cast<ASovereignBaseCharacter>(Owner))
		{
			if (BaseChar->IsLoadedCharacter())
			{
				return true;
			}
		}
		else if (ASovereignBaseEntity* BaseEntity = Cast<ASovereignBaseEntity>(Owner))
		{
			if (BaseEntity->IsLoadedEntity())
			{
				return true;
			}
		}

		// 4. SaveManager actively loading world state or DungeonSubsystem active expedition
		if (UWorld* World = Owner->GetWorld())
		{
			if (UGameInstance* GI = World->GetGameInstance())
			{
				if (USaveManager* SaveManager = GI->GetSubsystem<USaveManager>())
				{
					if (SaveManager->IsLoadingWorldState())
					{
						return true;
					}
				}

				if (USovereignDungeonSubsystem* DungeonSub = GI->GetSubsystem<USovereignDungeonSubsystem>())
				{
					if (DungeonSub->bHasActiveExpedition && (!DungeonSub->PartyLeaderStateJson.IsEmpty() || DungeonSub->ActivePartyMembersData.Num() > 0))
					{
						return true;
					}
				}
			}
		}
	}

	return false;
}

void USovereignAttributeComponent::SyncStatsFromEntity(bool bForce)
{
	// Absolute Guard: If an active dungeon expedition has saved state waiting to apply, block fresh syncs completely
	if (UWorld* World = GetWorld())
	{
		if (UGameInstance* GI = World->GetGameInstance())
		{
			if (USovereignDungeonSubsystem* DungeonSub = GI->GetSubsystem<USovereignDungeonSubsystem>())
			{
				if (DungeonSub->bHasActiveExpedition && !DungeonSub->PartyLeaderStateJson.IsEmpty())
				{
					UE_LOG(LogTemp, Log, TEXT("Sovereign: %s blocked SyncStatsFromEntity because a pending dungeon expedition state is waiting to load."),
						GetOwner() ? *GetOwner()->GetName() : TEXT("Unknown"));
					return;
				}
			}
		}
	}
	// Guard: Do not overwrite attributes if this is a loaded character, unless explicitly forced
	if (!bForce && IsLoadedCharacter())
	{
		UE_LOG(LogTemp, Log, TEXT("Sovereign: %s skipped SyncStatsFromEntity because it is a loaded character (preserved saved attributes)."),
			GetOwner() ? *GetOwner()->GetName() : TEXT("Unknown"));
		return;
	}

	USovereignSpeciesData* SpeciesData = nullptr;
	int32 StageIdx = 0;

	if (ASovereignBaseEntity* OwnerEntity = Cast<ASovereignBaseEntity>(GetOwner()))
	{
		SpeciesData = OwnerEntity->GetSpeciesData();
		StageIdx = OwnerEntity->GetCurrentGrowthStage();
	}
	else if (ASovereignBaseCharacter* OwnerChar = Cast<ASovereignBaseCharacter>(GetOwner()))
	{
		SpeciesData = OwnerChar->GetSpeciesData();
		StageIdx = OwnerChar->GetCurrentGrowthStage();
	}

	if (SpeciesData && SpeciesData->GrowthStages.IsValidIndex(StageIdx))
	{
		const FSovereignGrowthStage& Stage = SpeciesData->GrowthStages[StageIdx];

		float OldMaxHealth = GetMaxHealth();
		float HealthRatio = (OldMaxHealth > 0.0f) ? (CurrentHealth / OldMaxHealth) : 1.0f;

		Strength = Stage.BaseStrength;
		Dexterity = Stage.BaseDexterity;
		Constitution = Stage.BaseConstitution;
		Intelligence = Stage.BaseIntelligence;
		Wisdom = Stage.BaseWisdom;
		Charisma = Stage.BaseCharisma;
		Luck = Stage.BaseLuck;

		// Recalculate health bounds dynamically based on updated Constitution
		MaxHealth = GetMaxHealth();
		CurrentHealth = FMath::Clamp(HealthRatio * MaxHealth, 1.0f, MaxHealth);

		UE_LOG(LogTemp, Log, TEXT("Sovereign: %s synced D&D attributes from Species %s (Stage %d) -> STR:%d DEX:%d CON:%d INT:%d WIS:%d CHA:%d LCK:%d | HP: %.1f/%.1f"),
			*GetOwner()->GetName(), *SpeciesData->SpeciesName.ToString(), StageIdx,
			Strength, Dexterity, Constitution, Intelligence, Wisdom, Charisma, Luck, CurrentHealth, MaxHealth);
	}
	else
	{
		UE_LOG(LogTemp, Log, TEXT("Sovereign: %s synced default attributes."), GetOwner() ? *GetOwner()->GetName() : TEXT("Unknown"));
	}

	if (USovereignLevelComponent* LevelComp = GetOwner() ? GetOwner()->FindComponentByClass<USovereignLevelComponent>() : nullptr)
	{
		LevelComp->DetermineDefaultTrainingFocus();
	}
}

void USovereignAttributeComponent::OnPostLoad()
{
	if (MaxHealth <= 0.0f)
	{
		MaxHealth = GetMaxHealth();
	}
	CurrentHealth = FMath::Clamp(CurrentHealth, 1.0f, MaxHealth);
}
float USovereignAttributeComponent::GetMaxHealth() const
{
	// D&D Formula: Constitution acts as the multiplier.
	// We use 10.0f as a base, so 10 Con = 100 HP.
	return static_cast<float>(FMath::Max(1, Constitution)) * 10.0f;
}

float USovereignAttributeComponent::RecalculateMaxHealth(bool bResetToFull)
{
	const float BaseFromCon = GetMaxHealth();
	const float NewMaxHealth = FMath::Max(10.0f, BaseFromCon);

	if (bResetToFull || CurrentHealth <= 0.0f || MaxHealth <= 0.0f)
	{
		MaxHealth = NewMaxHealth;
		CurrentHealth = NewMaxHealth;
	}
	else
	{
		const float HealthRatio = (MaxHealth > 0.0f) ? (CurrentHealth / MaxHealth) : 1.0f;
		MaxHealth = NewMaxHealth;
		CurrentHealth = FMath::Clamp(HealthRatio * MaxHealth, 1.0f, MaxHealth);
	}
	return MaxHealth;
}

void USovereignAttributeComponent::InitializeAttributes(int32 InStr, int32 InDex, int32 InCon, int32 InInt, int32 InWis, int32 InCha, int32 InLck, float InBaseMaxHealth, float Multiplier)
{
	const float ClampedMult = FMath::Max(0.1f, Multiplier);

	Strength = FMath::Max(1, FMath::RoundToInt(InStr * ClampedMult));
	Dexterity = FMath::Max(1, FMath::RoundToInt(InDex * ClampedMult));
	Constitution = FMath::Max(1, FMath::RoundToInt(InCon * ClampedMult));
	Intelligence = FMath::Max(1, FMath::RoundToInt(InInt * ClampedMult));
	Wisdom = FMath::Max(1, FMath::RoundToInt(InWis * ClampedMult));
	Charisma = FMath::Max(1, FMath::RoundToInt(InCha * ClampedMult));
	Luck = FMath::Max(1, FMath::RoundToInt(InLck * ClampedMult));

	if (InBaseMaxHealth > 0.0f)
	{
		MaxHealth = FMath::Max(10.0f, InBaseMaxHealth * ClampedMult);
	}
	else
	{
		MaxHealth = FMath::Max(10.0f, GetMaxHealth());
	}
	CurrentHealth = MaxHealth;

	// Mark as loaded so default species sync in BeginPlay won't stomp these stats
	bIsLoadedFromSave = true;

	UE_LOG(LogTemp, Log, TEXT("Sovereign: %s initialized attributes from EnemyDefinition -> STR:%d DEX:%d CON:%d INT:%d WIS:%d CHA:%d LCK:%d | HP: %.1f/%.1f"),
		GetOwner() ? *GetOwner()->GetName() : TEXT("Unknown"),
		Strength, Dexterity, Constitution, Intelligence, Wisdom, Charisma, Luck, CurrentHealth, MaxHealth);
}

void USovereignAttributeComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// 1. GET POSSESSION MULTIPLIER
	float PossessionBonus = 1.0f;
	ASovereignBaseEntity* OwnerEntity = Cast<ASovereignBaseEntity>(GetOwner());

	if (OwnerEntity)
	{
		// Check the Brain component we built earlier
		auto ControlComp = OwnerEntity->FindComponentByClass<USovereignControllerComponent>();
		if (ControlComp && ControlComp->bIsPlayerPossessed)
		{
			PossessionBonus = 1.5f; // 50% faster regen and slower decay while player is inside
		}
	}
}

void USovereignAttributeComponent::OnSave(TSharedPtr<FJsonObject>& OutJson)
{
	TSharedPtr<FJsonObject> AttrObj = MakeShareable(new FJsonObject());

	AttrObj->SetNumberField(TEXT("Strength"), Strength);
	AttrObj->SetNumberField(TEXT("Dexterity"), Dexterity);
	AttrObj->SetNumberField(TEXT("Constitution"), Constitution);
	AttrObj->SetNumberField(TEXT("Intelligence"), Intelligence);
	AttrObj->SetNumberField(TEXT("Wisdom"), Wisdom);
	AttrObj->SetNumberField(TEXT("Charisma"), Charisma);
	AttrObj->SetNumberField(TEXT("Luck"), Luck);

	AttrObj->SetNumberField(TEXT("ArmourClass"), ArmourClass);

	AttrObj->SetNumberField(TEXT("CurrentHealth"), CurrentHealth);
	AttrObj->SetNumberField(TEXT("MaxHealth"), MaxHealth);
	AttrObj->SetNumberField(TEXT("CurrentStamina"), CurrentStamina);
	AttrObj->SetNumberField(TEXT("MaxStamina"), MaxStamina);

	AttrObj->SetNumberField(TEXT("PhysicalResistance"), PhysicalResistance);
	AttrObj->SetNumberField(TEXT("MagicalResistance"), MagicalResistance);
	AttrObj->SetNumberField(TEXT("MentalResistance"), MentalResistance);
	AttrObj->SetNumberField(TEXT("PoisonResistance"), PoisonResistance);
	AttrObj->SetNumberField(TEXT("SlowResistance"), SlowResistance);

	OutJson->SetObjectField(TEXT("Sovereign.Attributes"), AttrObj);
}

void USovereignAttributeComponent::OnLoad(const TSharedPtr<FJsonObject>& InJson)
{
	const TSharedPtr<FJsonObject>* AttrObj;
	if (InJson->TryGetObjectField(TEXT("Sovereign.Attributes"), AttrObj))
	{
		double Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("Strength"), Val)) Strength = (int32)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("Dexterity"), Val)) Dexterity = (int32)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("Constitution"), Val)) Constitution = (int32)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("Intelligence"), Val)) Intelligence = (int32)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("Wisdom"), Val)) Wisdom = (int32)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("Charisma"), Val)) Charisma = (int32)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("Luck"), Val)) Luck = (int32)Val;

		if ((*AttrObj)->TryGetNumberField(TEXT("ArmourClass"), Val)) ArmourClass = (int32)Val;

		if ((*AttrObj)->TryGetNumberField(TEXT("CurrentHealth"), Val)) CurrentHealth = (float)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("MaxHealth"), Val)) MaxHealth = (float)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("CurrentStamina"), Val)) CurrentStamina = (float)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("MaxStamina"), Val)) MaxStamina = (float)Val;

		if ((*AttrObj)->TryGetNumberField(TEXT("PhysicalResistance"), Val)) PhysicalResistance = (float)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("MagicalResistance"), Val)) MagicalResistance = (float)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("MentalResistance"), Val)) MentalResistance = (float)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("PoisonResistance"), Val)) PoisonResistance = (float)Val;
		if ((*AttrObj)->TryGetNumberField(TEXT("SlowResistance"), Val)) SlowResistance = (float)Val;

		bIsLoadedFromSave = true;

		// Ensure MaxHealth is recalculated based on loaded Constitution
		MaxHealth = GetMaxHealth();

		// Ensure CurrentHealth doesn't exceed the newly loaded MaxHealth
		CurrentHealth = FMath::Clamp(CurrentHealth, 1.0f, MaxHealth);

		UE_LOG(LogTemp, Log, TEXT("Sovereign: %s successfully loaded attributes from save data -> STR:%d DEX:%d CON:%d INT:%d WIS:%d CHA:%d LCK:%d | HP: %.1f/%.1f"),
			GetOwner() ? *GetOwner()->GetName() : TEXT("Unknown"),
			Strength, Dexterity, Constitution, Intelligence, Wisdom, Charisma, Luck, CurrentHealth, MaxHealth);
	}
}

void USovereignAttributeComponent::OnProcessData(const TMap<FString, FString>& Data)
{
	// Process attribute data
}