// Copyright (c) 2013-2026 Daniel Acourt. Version 36.4.1. Licensed under GPLv3 (See LICENSE). Last Updated: 2026-08-25

#include "Entities/SovereignSaveableEntityComponent.h"
#include "Entities/SovereignBrokerInterface.h"
#include "Entities/SovereignDiagnosticBroker.h"
#include "Entities/SovereignCultivationBroker.h"
#include "Components/SovereignQiComponent.h"
#include "Components/SovereignBioComponent.h"
#include "Components/SovereignAttributeComponent.h"
#include "Entities/SovereignBaseCharacter.h"
#include "Subsystems/SovereignBridgeSubsystem.h"
#include "SaveSystem/SovereignActorRegistry.h"
#include "Interaction/SovereignSaveInterface.h"
#include "Interaction/SovereignUIInspectable.h"
#include "JsonObjectConverter.h"
#include "Serialization/JsonSerializer.h"
#include "Engine/World.h"

USovereignSaveableEntityComponent::USovereignSaveableEntityComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
	UIUpdateThrottleInterval = 0.05f;
}

void USovereignSaveableEntityComponent::InvalidateStateCache()
{
	LastCachedFrame = 0;
	LastCachedTime = -1.0;
	CachedFullState.Reset();
	CachedCategoryStrings.Empty();
}

void USovereignSaveableEntityComponent::OnRegister()
{
	Super::OnRegister();

	// Instantiate the brokers dynamically at runtime and register them to our RegisteredBrokers list
	if (!DiagnosticBroker)
	{
		DiagnosticBroker = NewObject<UDiagnosticBroker>(this);
	}
	RegisterBroker(DiagnosticBroker);

	if (!CultivationBroker)
	{
		CultivationBroker = NewObject<UCultivationBroker>(this);
	}
	RegisterBroker(CultivationBroker);
}

void USovereignSaveableEntityComponent::BeginPlay()
{
	Super::BeginPlay();

	if (!EntityID.IsValid())
	{
		EntityID = FGuid::NewGuid();
	}

	if (UWorld* World = GetWorld())
	{
		// 1. Register with the Global Actor Registry
		if (UActorRegistry* Registry = World->GetSubsystem<UActorRegistry>())
		{
			Registry->RegisterActor(EntityID, GetOwner());
		}

		// 2. Register with the Bridge Subsystem for simulation tracking
		if (USovereignBridgeSubsystem* Bridge = World->GetSubsystem<USovereignBridgeSubsystem>())
		{
			Bridge->RegisterEntity(this);
		}
	}

	if (!BirthTimestamp.GetTicks())
	{
		BirthTimestamp = FDateTime::Now();
	}

	// Single Authority Broker Discovery: Auto-scan and register all attached actor components implementing ISovereignBrokerInterface
	if (AActor* Owner = GetOwner())
	{
		TArray<UActorComponent*> AttachedComponents;
		Owner->GetComponents(AttachedComponents);
		for (UActorComponent* Comp : AttachedComponents)
		{
			if (Comp && Comp != this && Comp->GetClass()->ImplementsInterface(USovereignBrokerInterface::StaticClass()))
			{
				TScriptInterface<ISovereignBrokerInterface> BrokerInterface(Comp);
				RegisterBroker(BrokerInterface);
			}
		}
	}
}

void USovereignSaveableEntityComponent::InitializeSoul()
{
	// 1. IDENTITY & BIRTHRIGHT
	if (!EntityID.IsValid()) { EntityID = FGuid::NewGuid(); }

	if (BirthTimestamp.GetTicks() == 0)
	{
		if (bUseManualBirthDate)
		{
			if (!FDateTime::Parse(ManualBirthDateStr, BirthTimestamp))
			{
				BirthTimestamp = FDateTime::Now();
				UE_LOG(LogTemp, Error, TEXT("Sovereign: Failed to parse ManualBirthDateStr! Defaulting to Now."));
			}
		}
		else
		{
			BirthTimestamp = FDateTime::Now();
		}
	}

	// 2. 07 CHECK-IN TELEMETRY
	if (UWorld* World = GetWorld())
	{
		if (USovereignBridgeSubsystem* Bridge = World->GetSubsystem<USovereignBridgeSubsystem>())
		{
			TSharedPtr<FJsonObject> State = CaptureFullEntityState();
			State->SetStringField(TEXT("Event"), TEXT("07_CheckIn_Initialize"));

			FString JsonString = SerializeJsonToString(State);
			Bridge->PushBlackBoxTelemetry(EntityID, 1.0f, JsonString);
		}
	}
}

void USovereignSaveableEntityComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (UWorld* World = GetWorld())
	{
		if (UActorRegistry* Registry = World->GetSubsystem<UActorRegistry>())
		{
			Registry->UnregisterActor(EntityID);
		}

		if (USovereignBridgeSubsystem* Bridge = World->GetSubsystem<USovereignBridgeSubsystem>())
		{
			Bridge->UnregisterEntity(this);
		}
	}
	Super::EndPlay(EndPlayReason);
}

void USovereignSaveableEntityComponent::RegisterBroker(TScriptInterface<ISovereignBrokerInterface> Broker)
{
	if (Broker.GetInterface() && !RegisteredBrokers.Contains(Broker))
	{
		RegisteredBrokers.Add(Broker);
		UE_LOG(LogTemp, Log, TEXT("Sovereign: Registered Module [%s] to Soul Hub."), *Broker.GetObject()->GetName());

		// Notify listeners that the architecture has changed and invalidate state cache
		InvalidateStateCache();
		OnStateChanged.Broadcast(this);
	}
}

USovereignQiComponent* USovereignSaveableEntityComponent::InfuseMagic()
{
	AActor* Owner = GetOwner();
	if (!Owner) return nullptr;

	USovereignQiComponent* QiComp = Owner->FindComponentByClass<USovereignQiComponent>();
	if (!QiComp)
	{
		QiComp = NewObject<USovereignQiComponent>(Owner, USovereignQiComponent::StaticClass(), TEXT("InfusedQiComponent"));
		if (QiComp)
		{
			Owner->AddInstanceComponent(QiComp);
			QiComp->RegisterComponent();
			TScriptInterface<ISovereignBrokerInterface> Broker(QiComp);
			RegisterBroker(Broker);
			UE_LOG(LogTemp, Log, TEXT("Sovereign: Infused Magic into %s"), *Owner->GetName());
		}
	}
	return QiComp;
}

bool USovereignSaveableEntityComponent::ExtractMagic()
{
	AActor* Owner = GetOwner();
	if (!Owner) return false;

	USovereignQiComponent* QiComp = Owner->FindComponentByClass<USovereignQiComponent>();
	if (QiComp)
	{
		TScriptInterface<ISovereignBrokerInterface> Broker(QiComp);
		UnregisterBroker(Broker);
		Owner->RemoveInstanceComponent(QiComp);
		QiComp->DestroyComponent();
		UE_LOG(LogTemp, Log, TEXT("Sovereign: Extracted Magic from %s"), *Owner->GetName());
		return true;
	}
	return false;
}

USovereignBioComponent* USovereignSaveableEntityComponent::InfuseLife()
{
	AActor* Owner = GetOwner();
	if (!Owner) return nullptr;

	USovereignBioComponent* BioComp = Owner->FindComponentByClass<USovereignBioComponent>();
	if (!BioComp)
	{
		BioComp = NewObject<USovereignBioComponent>(Owner, USovereignBioComponent::StaticClass(), TEXT("InfusedBioComponent"));
		if (BioComp)
		{
			Owner->AddInstanceComponent(BioComp);
			BioComp->RegisterComponent();
			TScriptInterface<ISovereignBrokerInterface> Broker(BioComp);
			RegisterBroker(Broker);
			UE_LOG(LogTemp, Log, TEXT("Sovereign: Infused Life into %s"), *Owner->GetName());
		}
	}
	return BioComp;
}

bool USovereignSaveableEntityComponent::ExtractLife()
{
	AActor* Owner = GetOwner();
	if (!Owner) return false;

	USovereignBioComponent* BioComp = Owner->FindComponentByClass<USovereignBioComponent>();
	if (BioComp)
	{
		TScriptInterface<ISovereignBrokerInterface> Broker(BioComp);
		UnregisterBroker(Broker);
		Owner->RemoveInstanceComponent(BioComp);
		BioComp->DestroyComponent();
		UE_LOG(LogTemp, Log, TEXT("Sovereign: Extracted Life from %s"), *Owner->GetName());
		return true;
	}
	return false;
}

USovereignAttributeComponent* USovereignSaveableEntityComponent::InfuseAttributes()
{
	AActor* Owner = GetOwner();
	if (!Owner) return nullptr;

	USovereignAttributeComponent* AttrComp = Owner->FindComponentByClass<USovereignAttributeComponent>();
	if (!AttrComp)
	{
		AttrComp = NewObject<USovereignAttributeComponent>(Owner, USovereignAttributeComponent::StaticClass(), TEXT("InfusedAttributeComponent"));
		if (AttrComp)
		{
			Owner->AddInstanceComponent(AttrComp);
			AttrComp->RegisterComponent();
			TScriptInterface<ISovereignBrokerInterface> Broker(AttrComp);
			RegisterBroker(Broker);
			UE_LOG(LogTemp, Log, TEXT("Sovereign: Infused Attributes into %s"), *Owner->GetName());
		}
	}
	return AttrComp;
}

bool USovereignSaveableEntityComponent::ExtractAttributes()
{
	AActor* Owner = GetOwner();
	if (!Owner) return false;

	USovereignAttributeComponent* AttrComp = Owner->FindComponentByClass<USovereignAttributeComponent>();
	if (AttrComp)
	{
		TScriptInterface<ISovereignBrokerInterface> Broker(AttrComp);
		UnregisterBroker(Broker);
		Owner->RemoveInstanceComponent(AttrComp);
		AttrComp->DestroyComponent();
		UE_LOG(LogTemp, Log, TEXT("Sovereign: Extracted Attributes from %s"), *Owner->GetName());
		return true;
	}
	return false;
}

void USovereignSaveableEntityComponent::UnregisterBroker(TScriptInterface<ISovereignBrokerInterface> Broker)
{
	if (RegisteredBrokers.Contains(Broker))
	{
		RegisteredBrokers.Remove(Broker);
		InvalidateStateCache();
		OnStateChanged.Broadcast(this);
	}
}

TSharedPtr<FJsonObject> USovereignSaveableEntityComponent::CaptureFullEntityState()
{
	TSharedPtr<FJsonObject> RootObj = MakeShareable(new FJsonObject());

	// 1. IDENTITY CATEGORY
	TSharedPtr<FJsonObject> IdentityObj = MakeShareable(new FJsonObject());
	FString EffectiveName = ObjectName.IsEmpty() ? (GetOwner() ? GetOwner()->GetName() : TEXT("")) : ObjectName;
	IdentityObj->SetStringField(TEXT("ObjectName"), EffectiveName);
	IdentityObj->SetStringField(TEXT("BirthTimestamp"), BirthTimestamp.ToString());
	IdentityObj->SetBoolField(TEXT("bIsBeingPossessed"), bIsBeingPossessed);
	IdentityObj->SetBoolField(TEXT("bIsMobile"), bIsMobile);
	IdentityObj->SetNumberField(TEXT("ParadoxDensity"), ParadoxDensity);
	if (AActor* Owner = GetOwner())
	{
		IdentityObj->SetStringField(TEXT("ActorName"), Owner->GetName());
		IdentityObj->SetStringField(TEXT("Class"), Owner->GetClass()->GetName());

		if (ASovereignBaseCharacter* BaseChar = Cast<ASovereignBaseCharacter>(Owner))
		{
			IdentityObj->SetNumberField(TEXT("GrowthStage"), BaseChar->GetCurrentGrowthStage());
		}
	}
	RootObj->SetObjectField(TEXT("Identity"), IdentityObj);

	// 1.5. SPATIAL TRANSFORM CATEGORY
	if (AActor* Owner = GetOwner())
	{
		TSharedPtr<FJsonObject> SpatialObj = MakeShareable(new FJsonObject());
		FVector Loc = Owner->GetActorLocation();
		FRotator Rot = Owner->GetActorRotation();

		TSharedPtr<FJsonObject> LocObj = MakeShareable(new FJsonObject());
		LocObj->SetNumberField(TEXT("X"), Loc.X);
		LocObj->SetNumberField(TEXT("Y"), Loc.Y);
		LocObj->SetNumberField(TEXT("Z"), Loc.Z);
		SpatialObj->SetObjectField(TEXT("Location"), LocObj);

		TSharedPtr<FJsonObject> RotObj = MakeShareable(new FJsonObject());
		RotObj->SetNumberField(TEXT("Pitch"), Rot.Pitch);
		RotObj->SetNumberField(TEXT("Yaw"), Rot.Yaw);
		RotObj->SetNumberField(TEXT("Roll"), Rot.Roll);
		SpatialObj->SetObjectField(TEXT("Rotation"), RotObj);

		RootObj->SetObjectField(TEXT("SpatialTransform"), SpatialObj);
	}

	// 2. UNKNOWN TAGS CATEGORY
	if (UnknownMetaTags.Num() > 0)
	{
		TSharedPtr<FJsonObject> TagsObj = MakeShareable(new FJsonObject());
		for (const auto& Elem : UnknownMetaTags)
		{
			TagsObj->SetStringField(Elem.Key, Elem.Value);
		}
		RootObj->SetObjectField(TEXT("UnknownTags"), TagsObj);
	}

	// Auto-discover attached components implementing ISovereignBrokerInterface prior to saving
	if (AActor* Owner = GetOwner())
	{
		TArray<UActorComponent*> AttachedComponents;
		Owner->GetComponents(AttachedComponents);
		for (UActorComponent* Comp : AttachedComponents)
		{
			if (Comp && Comp != this && Comp->GetClass()->ImplementsInterface(USovereignBrokerInterface::StaticClass()))
			{
				TScriptInterface<ISovereignBrokerInterface> BrokerInterface(Comp);
				if (!RegisteredBrokers.Contains(BrokerInterface))
				{
					RegisterBroker(BrokerInterface);
				}
			}
		}
	}

	// 3. MODULAR BROKER CATEGORIES
	for (auto& Broker : RegisteredBrokers)
	{
		if (Broker.GetInterface())
		{
			// Each broker adds its own named object to the root
			Broker->OnSave(RootObj);
		}
	}

	// 4. OWNER & COMPONENT FLAT SAVE DATA (ISovereignSaveInterface)
	if (AActor* Owner = GetOwner())
	{
		if (ISovereignSaveInterface* SaveInterface = Cast<ISovereignSaveInterface>(Owner))
		{
			TMap<FString, FString> SaveData = SaveInterface->GetSaveData();
			for (const auto& Elem : SaveData)
			{
				RootObj->SetStringField(Elem.Key, Elem.Value);
			}
		}

		TArray<UActorComponent*> Comps;
		Owner->GetComponents(Comps);
		for (UActorComponent* Comp : Comps)
		{
			if (Comp && Comp != this && Comp->GetClass()->ImplementsInterface(USovereignSaveInterface::StaticClass()))
			{
				if (ISovereignSaveInterface* SaveInterface = Cast<ISovereignSaveInterface>(Comp))
				{
					TMap<FString, FString> CompData = SaveInterface->GetSaveData();
					for (const auto& Elem : CompData)
					{
						RootObj->SetStringField(Elem.Key, Elem.Value);
					}
				}
			}
		}
	}

	return RootObj;
}

void USovereignSaveableEntityComponent::SetIsLoadedEntity(bool bLoaded)
{
	bIsLoadedEntity = bLoaded;

	for (auto& Broker : RegisteredBrokers)
	{
		if (UObject* BrokerObj = Broker.GetObject())
		{
			if (USovereignBaseComponent* BaseComp = Cast<USovereignBaseComponent>(BrokerObj))
			{
				BaseComp->SetLoadedFromSave(bLoaded);
			}
		}
	}

	if (AActor* Owner = GetOwner())
	{
		if (ASovereignBaseCharacter* BaseChar = Cast<ASovereignBaseCharacter>(Owner))
		{
			BaseChar->bIsLoadedCharacter = bLoaded;
		}
	}
}

void USovereignSaveableEntityComponent::ApplyStateFromJsonObject(const TSharedPtr<FJsonObject>& JsonData)
{
	if (!JsonData.IsValid()) return;

	SetIsLoadedEntity(true);

	// 1. RESTORE IDENTITY
	const TSharedPtr<FJsonObject>* IdentityObj;
	if (JsonData->TryGetObjectField(TEXT("Identity"), IdentityObj))
	{
		FString IdStr;
		if ((*IdentityObj)->TryGetStringField(TEXT("GUID"), IdStr)) FGuid::Parse(IdStr, EntityID);

		FString SavedObjectName;
		if ((*IdentityObj)->TryGetStringField(TEXT("ObjectName"), SavedObjectName)) ObjectName = SavedObjectName;

		FString BirthStr;
		if ((*IdentityObj)->TryGetStringField(TEXT("BirthTimestamp"), BirthStr)) FDateTime::Parse(BirthStr, BirthTimestamp);

		(*IdentityObj)->TryGetBoolField(TEXT("bIsBeingPossessed"), bIsBeingPossessed);

		double ParadoxVal;
		if ((*IdentityObj)->TryGetNumberField(TEXT("ParadoxDensity"), ParadoxVal)) ParadoxDensity = (float)ParadoxVal;

		double StageVal;
		if ((*IdentityObj)->TryGetNumberField(TEXT("GrowthStage"), StageVal))
		{
			if (ASovereignBaseCharacter* BaseChar = Cast<ASovereignBaseCharacter>(GetOwner()))
			{
				BaseChar->SetCurrentGrowthStage((int32)StageVal);
			}
		}
	}

	// 2. RESTORE UNKNOWN TAGS
	const TSharedPtr<FJsonObject>* TagsObj;
	if (JsonData->TryGetObjectField(TEXT("UnknownTags"), TagsObj))
	{
		UnknownMetaTags.Empty();
		for (auto& Elem : (*TagsObj)->Values)
		{
			UnknownMetaTags.Add(FString(Elem.Key), Elem.Value->AsString());
		}
	}

	// 2b. DYNAMIC COMPONENT INSTANTIATION ON LOAD (B-049)
	// If save data contains Sovereign.Magic, Sovereign.Bio, or Sovereign.Attributes JSON blocks, ensure those components exist on the owner
	if (JsonData->HasField(TEXT("Sovereign.Magic")))
	{
		InfuseMagic();
	}
	if (JsonData->HasField(TEXT("Sovereign.Bio")) || JsonData->HasField(TEXT("Bio")))
	{
		InfuseLife();
	}
	if (JsonData->HasField(TEXT("Sovereign.Attributes")))
	{
		InfuseAttributes();
	}

	// Auto-discover attached components implementing ISovereignBrokerInterface prior to restoring modules
	if (AActor* Owner = GetOwner())
	{
		TArray<UActorComponent*> AttachedComponents;
		Owner->GetComponents(AttachedComponents);
		for (UActorComponent* Comp : AttachedComponents)
		{
			if (Comp && Comp != this && Comp->GetClass()->ImplementsInterface(USovereignBrokerInterface::StaticClass()))
			{
				TScriptInterface<ISovereignBrokerInterface> BrokerInterface(Comp);
				if (!RegisteredBrokers.Contains(BrokerInterface))
				{
					RegisterBroker(BrokerInterface);
				}
			}
		}
	}

	// 3. RESTORE MODULES
	for (auto& Broker : RegisteredBrokers)
	{
		if (Broker.GetInterface())
		{
			Broker->OnLoad(JsonData);
		}
	}

	// 3b. POST-LOAD RECONCILIATION
		// Notify all brokers that loading is complete so they can recalculate bounds or defaults (e.g. Health, Training Focus)
	for (auto& Broker : RegisteredBrokers)
	{
		if (Broker.GetInterface())
		{
			Broker->OnPostLoad();
		}
	}

	// 4. RESTORE OWNER & COMPONENT FLAT SAVE DATA (ISovereignSaveInterface)
	if (AActor* Owner = GetOwner())
	{
		TMap<FString, FString> FlatData;
		for (const auto& Elem : JsonData->Values)
		{
			if (Elem.Value.IsValid())
			{
				if (Elem.Value->Type == EJson::String)
				{
					FlatData.Add(FString(Elem.Key), Elem.Value->AsString());
				}
				else if (Elem.Value->Type == EJson::Number)
				{
					FlatData.Add(FString(Elem.Key), FString::SanitizeFloat(Elem.Value->AsNumber()));
				}
			}
		}

		if (FlatData.Num() > 0)
		{
			if (ISovereignSaveInterface* SaveInterface = Cast<ISovereignSaveInterface>(Owner))
			{
				SaveInterface->RestoreSaveData(FlatData);
			}

			TArray<UActorComponent*> Comps;
			Owner->GetComponents(Comps);
			for (UActorComponent* Comp : Comps)
			{
				// FIX: Use USovereignSaveInterface instead of ISovereignSaveInterface for StaticClass() reflection
				if (Comp && Comp != this && Comp->GetClass()->ImplementsInterface(USovereignSaveInterface::StaticClass()))
				{
					if (ISovereignSaveInterface* SaveInterface = Cast<ISovereignSaveInterface>(Comp))
					{
						SaveInterface->RestoreSaveData(FlatData);
					}
				}
			}
		}
	}

	InvalidateStateCache();
	OnStateChanged.Broadcast(this);
}

void USovereignSaveableEntityComponent::ApplyMetaTags(TMap<FString, FString> LoadedTags)
{
	AActor* Owner = GetOwner();
	if (!Owner) return;

	for (auto& Elem : LoadedTags)
	{
		// 1. DNA FILTER: If it uses dot-notation (e.g., "Identity.Species.Wisp")
		if (Elem.Key.Contains(TEXT(".")))
		{
			// If it's a component-specific tag from an old save, we might want to skip it here
			// but for Legacy DNA, we try to ingest it.
			continue;
		}

		// 2. ELEMENTAL SOCKETS (Legacy fallback)
		// These should ideally be handled by the specialized components now.
		// For now, we just add them as Unknown Tags which will be processed by brokers.
		AddUnknownTag(Elem.Key, Elem.Value);
	}
}

FString USovereignSaveableEntityComponent::GetCategoryStateJson(FString CategoryName)
{
	uint64 CurrentFrame = GFrameCounter;
	double CurrentTime = -1.0;
	if (UWorld* World = GetWorld())
	{
		CurrentTime = World->GetTimeSeconds();
	}

	bool bShouldRebuild = false;
	if (!CachedFullState.IsValid())
	{
		bShouldRebuild = true;
	}
	else if (CurrentFrame != LastCachedFrame)
	{
		// New frame: check if the configured throttle interval has elapsed
		if (CurrentTime - LastCachedTime >= (double)UIUpdateThrottleInterval)
		{
			bShouldRebuild = true;
		}
	}

	if (bShouldRebuild)
	{
		CachedFullState = CaptureFullEntityState();
		LastCachedFrame = CurrentFrame;
		LastCachedTime = CurrentTime;
		CachedCategoryStrings.Empty();
	}

	if (FString* CachedStrPtr = CachedCategoryStrings.Find(CategoryName))
	{
		return *CachedStrPtr;
	}

	const TSharedPtr<FJsonObject>* CategoryObj;
	FString ResultString = TEXT("{}");
	if (CachedFullState->TryGetObjectField(CategoryName, CategoryObj))
	{
		ResultString = SerializeJsonToString(*CategoryObj);
	}

	CachedCategoryStrings.Add(CategoryName, ResultString);
	return ResultString;
}

void USovereignSaveableEntityComponent::AddUnknownTag(FString Key, FString Value)
{
	UnknownMetaTags.Add(Key, Value);

	if (Key.Contains(TEXT("Paradox")) || Key.Contains(TEXT("Conflict")) || Value.Equals(TEXT("Unknown"), ESearchCase::IgnoreCase))
	{
		ParadoxDensity = FMath::Clamp(ParadoxDensity + 0.1f, 0.0f, 1.0f);
	}

	// Notify brokers of the new "Truth"
	TMap<FString, FString> SingleTagMap;
	SingleTagMap.Add(Key, Value);

	for (auto& Broker : RegisteredBrokers)
	{
		if (Broker.GetInterface())
		{
			Broker->OnProcessData(SingleTagMap);
		}
	}

	InvalidateStateCache();
	OnStateChanged.Broadcast(this);
}

FString USovereignSaveableEntityComponent::SerializeJsonToString(TSharedPtr<FJsonObject> JsonObj)
{
	FString JsonString;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&JsonString);
	FJsonSerializer::Serialize(JsonObj.ToSharedRef(), Writer);
	return JsonString;
}

float USovereignSaveableEntityComponent::GetSystemConfidence_Implementation() const
{
	float BaseConfidence = 1.0f - ParadoxDensity;

	// Coupling with the Diagnostic Broker's curation status (VettedBy indicator)
	if (DiagnosticBroker && !DiagnosticBroker->VettedBy.IsEmpty())
	{
		// Curator validation mitigates 80% of current paradox/uncertainty density, boosting the system confidence.
		BaseConfidence = 1.0f - (ParadoxDensity * 0.2f);
	}

	return FMath::Clamp(BaseConfidence, 0.0f, 1.0f);
}

TArray<UActorComponent*> USovereignSaveableEntityComponent::GetInspectableComponents(AActor* TargetActor)
{
	TArray<UActorComponent*> Results;
	if (!TargetActor)
	{
		return Results;
	}

	TArray<UActorComponent*> Components;
	TargetActor->GetComponents(Components);

	for (UActorComponent* Comp : Components)
	{
		if (Comp && Comp->GetClass()->ImplementsInterface(USovereignUIInspectable::StaticClass()))
		{
			Results.Add(Comp);
		}
	}

	return Results;
}

FString USovereignSaveableEntityComponent::GetAggregatedInspectionJson(AActor* TargetActor)
{
	if (!TargetActor)
	{
		return TEXT("{}");
	}

	TSharedPtr<FJsonObject> RootObj = MakeShared<FJsonObject>();
	RootObj->SetStringField(TEXT("ActorName"), TargetActor->GetName());

	TArray<TSharedPtr<FJsonValue>> ComponentList;
	TArray<UActorComponent*> Inspectables = GetInspectableComponents(TargetActor);

	for (UActorComponent* Comp : Inspectables)
	{
		if (!Comp)
		{
			continue;
		}

		FString CompJsonStr = ISovereignUIInspectable::Execute_GetInspectorDataJson(Comp);
		TSharedPtr<FJsonObject> CompJsonObj;
		TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(CompJsonStr);

		if (FJsonSerializer::Deserialize(Reader, CompJsonObj) && CompJsonObj.IsValid())
		{
			ComponentList.Add(MakeShared<FJsonValueObject>(CompJsonObj));
		}
	}

	RootObj->SetArrayField(TEXT("InspectableComponents"), ComponentList);

	FString OutputString;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&OutputString);
	FJsonSerializer::Serialize(RootObj.ToSharedRef(), Writer);

	return OutputString;
}

#if WITH_EDITOR
void USovereignSaveableEntityComponent::PostEditImport() { Super::PostEditImport(); EntityID = FGuid::NewGuid(); }

void USovereignSaveableEntityComponent::PostDuplicate(bool bDuplicateForPIE)
{
	Super::PostDuplicate(bDuplicateForPIE);
	if (!bDuplicateForPIE) { EntityID = FGuid::NewGuid(); }
}
#endif
