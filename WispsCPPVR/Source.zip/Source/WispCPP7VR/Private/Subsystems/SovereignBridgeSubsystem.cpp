// Copyright (c) 2013-2025 Daniel Acourt. Version 36.4.7. Licensed under GPLv3 (See LICENSE).

// // [J] Tactical Implementation of the 07 Handshake and Telemetry Pipeline. 2025-06-18

#include "Subsystems/SovereignBridgeSubsystem.h"
#include "Utilities/SovereignTTSSanitizer.h"
#include "Entities/SovereignSaveableEntityComponent.h"
#include "Entities/SovereignIronKnightAgent.h"
#include "HttpModule.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "Serialization/JsonSerializer.h"
#include "Dom/JsonObject.h"
#include "Misc/Paths.h"
#include "Misc/FileHelper.h"
#include "AIController.h"
#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "Interaction/SovereignInterfaceMain.h"
#include "NavigationSystem.h"

void USovereignBridgeSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
    Super::Initialize(Collection);

    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Subsystem Initializing..."));
    LoadConfiguration();

    // Auto-initiate 07 Check-In upon world start
    Perform07CheckIn();
}

void USovereignBridgeSubsystem::Deinitialize()
{
    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Subsystem Deinitializing. Clearing %d registered entities."), RegisteredSovereignEntities.Num());
    StopMailboxPolling();
    RegisteredSovereignEntities.Empty();

    Super::Deinitialize();
}

void USovereignBridgeSubsystem::LoadConfiguration()
{
    FString ConfigPath = GetConfigPath();
    FString ConfigContent;

    if (FFileHelper::LoadFileToString(ConfigContent, *ConfigPath))
    {
        TSharedPtr<FJsonObject> JsonObject;
        TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ConfigContent);

        if (FJsonSerializer::Deserialize(Reader, JsonObject) && JsonObject.IsValid())
        {
            if (JsonObject->HasField(TEXT("BridgeBaseUrl")))
            {
                BridgeBaseUrl = JsonObject->GetStringField(TEXT("BridgeBaseUrl"));
                UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Loaded URL %s from config."), *BridgeBaseUrl);
            }
        }
    }
    else
    {
        UE_LOG(LogTemp, Log, TEXT("SovereignBridge: bridge_config.json not found at %s. Using default: %s"), *ConfigPath, *BridgeBaseUrl);
    }
}

FString USovereignBridgeSubsystem::GetConfigPath() const
{
    return FPaths::ProjectSavedDir() / TEXT("Config/bridge_config.json");
}

void USovereignBridgeSubsystem::Perform07CheckIn()
{
    // // [J] The 07 Protocol ensures we boot up and 'check in' with the Lead's GTX 5090 before simulation starts.
    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Initiating 07 Protocol Check-In..."));

    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
    Request->OnProcessRequestComplete().BindUObject(this, &USovereignBridgeSubsystem::OnCheckInResponse);
    Request->SetURL(BridgeBaseUrl / TEXT("v1/unreal/checkin"));
    Request->SetVerb(TEXT("POST"));
    Request->SetHeader(TEXT("Content-Type"), TEXT("application/json"));

    TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());
    JsonObject->SetStringField(TEXT("client_name"), TEXT("Wisp_Simulation_Engine"));
    JsonObject->SetStringField(TEXT("version"), TEXT("36.4.7"));

    FString RequestBody;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&RequestBody);
    FJsonSerializer::Serialize(JsonObject.ToSharedRef(), Writer);

    Request->SetContentAsString(RequestBody);
    Request->ProcessRequest();
}

void USovereignBridgeSubsystem::ExecuteAASHandshake()
{
    // // [J] Requests a temporary +0.5 VSS authority boost from the bridge to dynamically clear 409 Conflict Gates.
    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Executing AAS Handshake..."));

    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
    Request->OnProcessRequestComplete().BindLambda([this](FHttpRequestPtr Req, FHttpResponsePtr Res, bool bWasSucc)
    {
        if (bWasSucc && Res.IsValid() && EHttpResponseCodes::IsOk(Res->GetResponseCode()))
        {
            bHandshakeActive = true;
            UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: AAS Handshake successful! Global Authority Boost Active."));
            FlushTelemetryQueue();
        }
        else
        {
            UE_LOG(LogTemp, Error, TEXT("SovereignBridge: AAS Handshake failed."));
        }
    });

    Request->SetURL(BridgeBaseUrl + TEXT("/v1/aas/handshake"));
    Request->SetVerb(TEXT("POST"));
    Request->SetHeader(TEXT("Content-Type"), TEXT("application/json"));
    Request->ProcessRequest();
}

void USovereignBridgeSubsystem::CreateSimulationFile(const FString& FilePath, const FString& Content)
{
    // // [J] Direct programmatic file creation bypassing the conversational LLM. 2026-06-28
    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Creating simulation file [%s]..."), *FilePath);

    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
    Request->OnProcessRequestComplete().BindLambda([this, FilePath](FHttpRequestPtr Req, FHttpResponsePtr Res, bool bWasSucc)
    {
        if (bWasSucc && Res.IsValid() && EHttpResponseCodes::IsOk(Res->GetResponseCode()))
        {
            UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: File [%s] created successfully!"), *FilePath);
        }
        else
        {
            FString ResponseStr = Res.IsValid() ? Res->GetContentAsString() : TEXT("No Response");
            UE_LOG(LogTemp, Error, TEXT("SovereignBridge: File [%s] creation failed. Details: %s"), *FilePath, *ResponseStr);
        }
    });

    Request->SetURL(BridgeBaseUrl + TEXT("/v1/unreal/create_file"));
    Request->SetVerb(TEXT("POST"));
    Request->SetHeader(TEXT("Content-Type"), TEXT("application/json"));

    TSharedPtr<FJsonObject> JsonPayload = MakeShareable(new FJsonObject());
    JsonPayload->SetStringField(TEXT("filepath"), FilePath);
    JsonPayload->SetStringField(TEXT("content"), Content);
    JsonPayload->SetStringField(TEXT("persona"), TEXT("Unreal_Simulation"));

    FString RequestBody;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&RequestBody);
    FJsonSerializer::Serialize(JsonPayload.ToSharedRef(), Writer);

    Request->SetContentAsString(RequestBody);
    Request->ProcessRequest();
}

void USovereignBridgeSubsystem::GenerateDNDPersona(const FString& CharacterName, bool bRandomGenerate)
{
    // // [J] Direct programmatic character sheet generation and indexing. 2026-06-28
    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Requesting DND Persona generation for [%s] (Random: %s)..."), *CharacterName, bRandomGenerate ? TEXT("True") : TEXT("False"));

    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
    Request->OnProcessRequestComplete().BindLambda([this, CharacterName](FHttpRequestPtr Req, FHttpResponsePtr Res, bool bWasSucc)
    {
        if (bWasSucc && Res.IsValid() && EHttpResponseCodes::IsOk(Res->GetResponseCode()))
        {
            UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: DND Persona [%s] generated and indexed successfully!"), *CharacterName);
        }
        else
        {
            FString ResponseStr = Res.IsValid() ? Res->GetContentAsString() : TEXT("No Response");
            UE_LOG(LogTemp, Error, TEXT("SovereignBridge: DND Persona [%s] generation failed. Details: %s"), *CharacterName, *ResponseStr);
        }
    });

    Request->SetURL(BridgeBaseUrl + TEXT("/v1/unreal/generate_persona"));
    Request->SetVerb(TEXT("POST"));
    Request->SetHeader(TEXT("Content-Type"), TEXT("application/json"));

    TSharedPtr<FJsonObject> JsonPayload = MakeShareable(new FJsonObject());
    JsonPayload->SetStringField(TEXT("character_name"), CharacterName);
    JsonPayload->SetBoolField(TEXT("random_generate"), bRandomGenerate);
    JsonPayload->SetStringField(TEXT("persona"), TEXT("Unreal_Simulation"));

    FString RequestBody;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&RequestBody);
    FJsonSerializer::Serialize(JsonPayload.ToSharedRef(), Writer);

    Request->SetContentAsString(RequestBody);
    Request->ProcessRequest();
}

void USovereignBridgeSubsystem::SendSimulationChat(const FString& ActorName, const FString& Message, const TArray<FSovereignChatMessage>& History)
{
    // // [J] Bridging the simulation's voice to the Lead's AI. 2025-06-18
    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Outgoing Chat from Simulation Actor [%s]."), *ActorName);

    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
    Request->OnProcessRequestComplete().BindUObject(this, &USovereignBridgeSubsystem::OnChatResponse);
    Request->SetURL(BridgeBaseUrl + TEXT("/v1/unreal/chat"));
    Request->SetVerb(TEXT("POST"));
    Request->SetHeader(TEXT("Content-Type"), TEXT("application/json"));

    TSharedPtr<FJsonObject> JsonPayload = MakeShareable(new FJsonObject());
    JsonPayload->SetStringField(TEXT("actor_name"), ActorName);
    JsonPayload->SetStringField(TEXT("message"), Message);
    JsonPayload->SetBoolField(TEXT("enable_remote_history"), bEnableRemoteHistory);

    // Build a complete world_manifest mapping all registered Sovereign entities in the current world
    TSharedPtr<FJsonObject> WorldManifestObj = MakeShareable(new FJsonObject());
    TSharedPtr<FJsonObject> CallerStateObj;

    for (const TWeakObjectPtr<USovereignSaveableEntityComponent>& EntityPtr : RegisteredSovereignEntities)
    {
        if (EntityPtr.IsValid())
        {
            AActor* Owner = EntityPtr->GetOwner();
            if (Owner)
            {
                FString OwnerName = Owner->GetName();
                TSharedPtr<FJsonObject> EntityState = EntityPtr->CaptureFullEntityState();
                WorldManifestObj->SetObjectField(OwnerName, EntityState);

                FString CleanActorName = ActorName.Replace(TEXT("SIM_"), TEXT(""));
                FString CleanOwnerName = OwnerName.Replace(TEXT("SIM_"), TEXT(""));

                if (OwnerName == ActorName ||
                    CleanOwnerName == CleanActorName ||
                    CleanOwnerName.StartsWith(CleanActorName) ||
                    CleanActorName.StartsWith(CleanOwnerName))
                {
                    CallerStateObj = EntityState;
                    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Found Calling Registered Entity [%s] for Actor [%s]."), *OwnerName, *ActorName);
                }
            }
        }
    }

    // Attach world_manifest for multi-entity spatial sense (AD-005a)
    JsonPayload->SetObjectField(TEXT("world_manifest"), WorldManifestObj);

    // Provide primary save_state for caller fallback compatibility
    if (CallerStateObj.IsValid())
    {
        JsonPayload->SetObjectField(TEXT("save_state"), CallerStateObj);
    }

    // Serialize History
    TArray<TSharedPtr<FJsonValue>> HistoryArray;
    for (const FSovereignChatMessage& Msg : History)
    {
        TSharedPtr<FJsonObject> MsgObj = MakeShareable(new FJsonObject());
        MsgObj->SetStringField(TEXT("role"), Msg.Role);
        MsgObj->SetStringField(TEXT("content"), Msg.Content);
        if (!Msg.Name.IsEmpty())
        {
            MsgObj->SetStringField(TEXT("name"), Msg.Name);
        }
        HistoryArray.Add(MakeShareable(new FJsonValueObject(MsgObj)));
    }
    JsonPayload->SetArrayField(TEXT("history"), HistoryArray);

    FString RequestBody;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&RequestBody);
    FJsonSerializer::Serialize(JsonPayload.ToSharedRef(), Writer);

    Request->SetContentAsString(RequestBody);
    Request->ProcessRequest();
}

void USovereignBridgeSubsystem::PushBlackBoxTelemetry(const FGuid& EntityID, float PSTAScore, const FString& BlackBoxJson)
{
    if (!bHandshakeActive)
    {
        UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Handshake pending. Queuing telemetry for Entity %s"), *EntityID.ToString());
        TelemetryQueue.Add({EntityID, PSTAScore, BlackBoxJson});
        return;
    }

    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
    Request->OnProcessRequestComplete().BindUObject(this, &USovereignBridgeSubsystem::OnTelemetryResponse);
    Request->SetURL(BridgeBaseUrl / TEXT("v1/unreal/telemetry"));
    Request->SetVerb(TEXT("POST"));
    Request->SetHeader(TEXT("Content-Type"), TEXT("application/json"));

    // Parse the BlackBoxJson string back into an object to embed it in the payload
    TSharedPtr<FJsonObject> BlackBoxObj;
    TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(BlackBoxJson);
    if (!FJsonSerializer::Deserialize(Reader, BlackBoxObj) || !BlackBoxObj.IsValid())
    {
        UE_LOG(LogTemp, Error, TEXT("SovereignBridge: Failed to parse BlackBox JSON string."));
        return;
    }

    TSharedPtr<FJsonObject> JsonPayload = MakeShareable(new FJsonObject());
    JsonPayload->SetStringField(TEXT("entity_id"), EntityID.ToString());
    JsonPayload->SetNumberField(TEXT("psta_score"), PSTAScore);
    JsonPayload->SetObjectField(TEXT("blackbox_data"), BlackBoxObj);
    JsonPayload->SetStringField(TEXT("persona"), TEXT("Unreal_Simulation"));

    FString RequestBody;
    TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&RequestBody);
    FJsonSerializer::Serialize(JsonPayload.ToSharedRef(), Writer);

    Request->SetContentAsString(RequestBody);
    Request->ProcessRequest();
}

void USovereignBridgeSubsystem::RegisterEntity(USovereignSaveableEntityComponent* Soul)
{
    if (Soul && !RegisteredSovereignEntities.Contains(Soul))
    {
        RegisteredSovereignEntities.Add(Soul);
        UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Registered Entity %s. Total: %d"), *Soul->EntityID.ToString(), RegisteredSovereignEntities.Num());
    }
}

void USovereignBridgeSubsystem::UnregisterEntity(USovereignSaveableEntityComponent* Soul)
{
    if (Soul)
    {
        RegisteredSovereignEntities.Remove(Soul);
        UE_LOG(LogTemp, Log, TEXT("SovereignBridge: Unregistered Entity %s. Total: %d"), *Soul->EntityID.ToString(), RegisteredSovereignEntities.Num());
    }
}

int32 USovereignBridgeSubsystem::GetRegisteredEntityCount() const
{
    return RegisteredSovereignEntities.Num();
}

void USovereignBridgeSubsystem::FlushTelemetryQueue()
{
    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Flushing %d queued telemetry packets..."), TelemetryQueue.Num());

    for (const FPendingTelemetry& Pending : TelemetryQueue)
    {
        PushBlackBoxTelemetry(Pending.EntityID, Pending.PSTAScore, Pending.BlackBoxJson);
    }

    TelemetryQueue.Empty();
}

void USovereignBridgeSubsystem::OnCheckInResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
    if (bWasSuccessful && Response.IsValid() && EHttpResponseCodes::IsOk(Response->GetResponseCode()))
    {
        TSharedPtr<FJsonObject> JsonObject;
        TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Response->GetContentAsString());

        if (FJsonSerializer::Deserialize(Reader, JsonObject) && JsonObject.IsValid())
        {
            FString Status = JsonObject->GetStringField(TEXT("status"));

            if (Status == TEXT("200_OK"))
            {
                FString Message = JsonObject->GetStringField(TEXT("message"));
                float VSS = JsonObject->GetNumberField(TEXT("psta_vss"));

                bHandshakeActive = true;
                UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: 07 Check-In Successful! %s (VSS: %f)"), *Message, VSS);

                // Flush any telemetry queued during the handshake
                FlushTelemetryQueue();
            }
            else
            {
                UE_LOG(LogTemp, Error, TEXT("SovereignBridge: Bridge returned non-OK status for Check-In: %s"), *Status);
            }
        }
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("SovereignBridge: 07 Check-In FAILED. Bridge may be offline."));
    }
}

void USovereignBridgeSubsystem::OnTelemetryResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
    if (bWasSuccessful && Response.IsValid() && EHttpResponseCodes::IsOk(Response->GetResponseCode()))
    {
        TSharedPtr<FJsonObject> JsonObject;
        TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Response->GetContentAsString());

        if (FJsonSerializer::Deserialize(Reader, JsonObject) && JsonObject.IsValid())
        {
            FString Status = JsonObject->GetStringField(TEXT("status"));
            if (Status == TEXT("200_OK"))
            {
                UE_LOG(LogTemp, Log, TEXT("SovereignBridge: Telemetry successfully acknowledged by bridge."));
            }
            else if (Status == TEXT("409_CONFLICT_GATE"))
            {
                UE_LOG(LogTemp, Error, TEXT("SovereignBridge: Telemetry BLOCKED by AAS Conflict Gate."));
            }
            else
            {
                UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Telemetry response status: %s"), *Status);
            }
        }
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("SovereignBridge: Telemetry push failed. Network error."));
    }
}

void USovereignBridgeSubsystem::OnChatResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
    if (bWasSuccessful && Response.IsValid() && EHttpResponseCodes::IsOk(Response->GetResponseCode()))
    {
        TSharedPtr<FJsonObject> JsonObject;
        TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Response->GetContentAsString());

        if (FJsonSerializer::Deserialize(Reader, JsonObject) && JsonObject.IsValid())
        {
            FSovereignChatResponse ChatResponse;
            ChatResponse.Content = JsonObject->GetStringField(TEXT("response"));

            if (JsonObject->HasTypedField<EJson::String>(TEXT("spoken_dialogue")))
            {
                ChatResponse.SpokenDialogue = JsonObject->GetStringField(TEXT("spoken_dialogue"));
            }
            else
            {
                ChatResponse.SpokenDialogue = USovereignTTSSanitizer::SanitizeTextForTTS(ChatResponse.Content);
            }

            const TArray<TSharedPtr<FJsonValue>>* ChunksArray;
            if (JsonObject->TryGetArrayField(TEXT("tts_chunks"), ChunksArray))
            {
                for (const auto& ChunkVal : *ChunksArray)
                {
                    ChatResponse.TTSChunks.Add(ChunkVal->AsString());
                }
            }
            else
            {
                ChatResponse.TTSChunks = USovereignTTSSanitizer::ChunkTextForTTS(ChatResponse.Content);
            }

            // // [J] Parsing diagnostic tool logs returned from the Iron Officer Bridge. 2025-06-18
            const TArray<TSharedPtr<FJsonValue>>* ToolLogsArray;
            if (JsonObject->TryGetArrayField(TEXT("tool_logs"), ToolLogsArray))
            {
                for (auto& LogValue : *ToolLogsArray)
                {
                    TSharedPtr<FJsonObject> ToolLogObj = LogValue->AsObject();
                    if (ToolLogObj.IsValid())
                    {
                        FSovereignChatLog LogEntry;
                        FString OutputStr;
                        TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&OutputStr);
                        FJsonSerializer::Serialize(ToolLogObj.ToSharedRef(), Writer);

                        LogEntry.ToolName = TEXT("Tool");
                        LogEntry.ResultSnippet = OutputStr.Left(200);
                        ChatResponse.ToolLogs.Add(LogEntry);
                    }
                }
            }

            // Cross-reference with tool_chain to resolve functional names
            const TArray<TSharedPtr<FJsonValue>>* ToolChainArray;
            if (JsonObject->TryGetArrayField(TEXT("tool_chain"), ToolChainArray))
            {
                for (int32 i = 0; i < ToolChainArray->Num() && i < ChatResponse.ToolLogs.Num(); ++i)
                {
                    TSharedPtr<FJsonObject> ToolObj = (*ToolChainArray)[i]->AsObject();
                    if (ToolObj.IsValid())
                    {
                        TSharedPtr<FJsonObject> FuncObj = ToolObj->GetObjectField(TEXT("function"));
                        if (FuncObj.IsValid())
                        {
                            ChatResponse.ToolLogs[i].ToolName = FuncObj->GetStringField(TEXT("name"));
                            UE_LOG(LogTemp, Log, TEXT("SovereignBridge: AI Executed Tool: %s"), *ChatResponse.ToolLogs[i].ToolName);
                        }
                    }
                }
            }

            UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Chat Response Received (%d tools executed)"), ChatResponse.ToolLogs.Num());
            UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: AI Response: %s"), *ChatResponse.Content);
            OnChatResponseReceived.Broadcast(ChatResponse);
        }
    }
    else
    {
        FString ErrorDetail = Response.IsValid() ? FString::Printf(TEXT("Code: %d"), Response->GetResponseCode()) : TEXT("Network Error");
        UE_LOG(LogTemp, Error, TEXT("SovereignBridge: Simulation Chat FAILED. %s"), *ErrorDetail);
    }
}

void USovereignBridgeSubsystem::StartMailboxPolling(const FString& ActorName)
{
    if (ActorName.StartsWith(TEXT("SIM_")))
    {
        PollingActorName = ActorName;
    }
    else
    {
        PollingActorName = FString::Printf(TEXT("SIM_%s"), *ActorName);
    }

    // Stop any active polling first to avoid redundant timer accumulation
    StopMailboxPolling();

    UWorld* World = GetWorld();
    if (World)
    {
        World->GetTimerManager().SetTimer(
            MailboxTimerHandle,
            this,
            &USovereignBridgeSubsystem::QueryMailbox,
            MailboxPollInterval,
            true
        );
        UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Started Mailbox Polling loop for [%s] every %f seconds."), *PollingActorName, MailboxPollInterval);
    }
}

void USovereignBridgeSubsystem::StopMailboxPolling()
{
    UWorld* World = GetWorld();
    if (World)
    {
        World->GetTimerManager().ClearTimer(MailboxTimerHandle);
    }

    TSharedPtr<IHttpRequest, ESPMode::ThreadSafe> RequestPtr = ActiveMailboxRequest.Pin();
    if (RequestPtr.IsValid())
    {
        RequestPtr->CancelRequest();
        UE_LOG(LogTemp, Log, TEXT("SovereignBridge: Canceled active in-flight mailbox request."));
    }

    UE_LOG(LogTemp, Log, TEXT("SovereignBridge: Stopped Mailbox Polling."));
}

void USovereignBridgeSubsystem::QueryMailbox()
{
    if (PollingActorName.IsEmpty()) return;

    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
    Request->OnProcessRequestComplete().BindUObject(this, &USovereignBridgeSubsystem::OnMailboxResponse);

    ActiveMailboxRequest = Request;

    // Use string concatenation (+) to avoid path separator operator compilation ambiguity
    FString TargetURL = BridgeBaseUrl + TEXT("/v1/unreal/mailbox?actor_name=") + PollingActorName;
    Request->SetURL(TargetURL);
    Request->SetVerb(TEXT("GET"));
    Request->ProcessRequest();
}

void USovereignBridgeSubsystem::OnMailboxResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
    if (bWasSuccessful && Response.IsValid() && EHttpResponseCodes::IsOk(Response->GetResponseCode()))
    {
        TSharedPtr<FJsonObject> JsonObject;
        TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Response->GetContentAsString());

        if (FJsonSerializer::Deserialize(Reader, JsonObject) && JsonObject.IsValid())
        {
            const TArray<TSharedPtr<FJsonValue>>* MessagesArray;
            if (JsonObject->TryGetArrayField(TEXT("messages"), MessagesArray))
            {
                for (const TSharedPtr<FJsonValue>& MsgVal : *MessagesArray)
                {
                    FString PushedMessage = MsgVal->AsString();
                    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: AI Pushed Proactive Chat: %s"), *PushedMessage);

                    // Inspect for Directive commands (AD-027)
                    if (PushedMessage.StartsWith(TEXT("[DIRECTIVE:")))
                    {
                        ProcessRuntimeDirective(PushedMessage);
                    }

                    // Broadcast to UI Widgets, subtitles, or character dialogue systems
                    OnAIChatPushed.Broadcast(PushedMessage);
                }
            }
        }
    }
}

FString USovereignBridgeSubsystem::SanitizeTextForTTS(const FString& InText)
{
    return USovereignTTSSanitizer::SanitizeTextForTTS(InText);
}

TArray<FString> USovereignBridgeSubsystem::ChunkTextForTTS(const FString& InText, int32 MaxChars)
{
    return USovereignTTSSanitizer::ChunkTextForTTS(InText, MaxChars);
}

bool USovereignBridgeSubsystem::ProcessRuntimeDirective(const FString& DirectiveMessage)
{
    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Processing Runtime Directive: %s"), *DirectiveMessage);

    // Format: [DIRECTIVE:ActionName] sender=SIM_IronKnight target=TargetName params={...}
    if (!DirectiveMessage.StartsWith(TEXT("[DIRECTIVE:")))
    {
        return false;
    }

    int32 ClosingBracketIdx = DirectiveMessage.Find(TEXT("]"));
    if (ClosingBracketIdx == INDEX_NONE)
    {
        return false;
    }

    FString ActionName = DirectiveMessage.Mid(11, ClosingBracketIdx - 11);
    FString Payload = DirectiveMessage.Mid(ClosingBracketIdx + 1).TrimStart();

    // Extract Target Name
    FString TargetName;
    int32 TargetIdx = Payload.Find(TEXT("target="));
    if (TargetIdx != INDEX_NONE)
    {
        FString TargetSub = Payload.Mid(TargetIdx + 7);
        int32 SpaceIdx = TargetSub.Find(TEXT(" "));
        TargetName = (SpaceIdx != INDEX_NONE) ? TargetSub.Left(SpaceIdx) : TargetSub;
    }

    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Directive Parsed - Action: '%s', Target: '%s'"), *ActionName, *TargetName);

    // Extract Params String
    FString ParamsJsonStr;
    int32 ParamsIdx = Payload.Find(TEXT("params="));
    if (ParamsIdx != INDEX_NONE)
    {
        ParamsJsonStr = Payload.Mid(ParamsIdx + 7).TrimStart();
    }

    // Parse target_vessel from Params JSON if present
    FString TargetVesselStr;
    if (!ParamsJsonStr.IsEmpty())
    {
        TSharedPtr<FJsonObject> ParamsJsonObj;
        TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ParamsJsonStr);
        if (FJsonSerializer::Deserialize(Reader, ParamsJsonObj) && ParamsJsonObj.IsValid())
        {
            if (ParamsJsonObj->HasField(TEXT("target_vessel")))
            {
                TargetVesselStr = ParamsJsonObj->GetStringField(TEXT("target_vessel"));
            }
        }
    }

    // Find Target Agent Entity
    ASovereignIronKnightAgent* TargetAgent = nullptr;
    for (TWeakObjectPtr<USovereignSaveableEntityComponent>& EntityPtr : RegisteredSovereignEntities)
    {
        if (EntityPtr.IsValid())
        {
            AActor* OwnerActor = EntityPtr->GetOwner();
            if (OwnerActor && (OwnerActor->GetName() == TargetName || OwnerActor->GetName().Contains(TargetName) || TargetName.Contains(OwnerActor->GetName())))
            {
                if (ASovereignIronKnightAgent* Agent = Cast<ASovereignIronKnightAgent>(OwnerActor))
                {
                    TargetAgent = Agent;
                    break;
                }
            }
        }
    }

    // Fallback search for Iron Knight Agent in world if target match did not cast to agent directly
    if (!TargetAgent)
    {
        for (TWeakObjectPtr<USovereignSaveableEntityComponent>& EntityPtr : RegisteredSovereignEntities)
        {
            if (EntityPtr.IsValid() && EntityPtr->GetOwner())
            {
                if (ASovereignIronKnightAgent* Agent = Cast<ASovereignIronKnightAgent>(EntityPtr->GetOwner()))
                {
                    TargetAgent = Agent;
                    break;
                }
            }
        }
    }

    if (TargetAgent)
    {
        if (ActionName == TEXT("PerformAgentPossession"))
        {
            AActor* ResolvedVessel = nullptr;

            if (!TargetVesselStr.IsEmpty())
            {
                FString CleanTargetVessel = TargetVesselStr.Replace(TEXT("SIM_"), TEXT(""));

                // Priority 1: EntityID / GUID Match
                for (TWeakObjectPtr<USovereignSaveableEntityComponent>& EntityPtr : RegisteredSovereignEntities)
                {
                    if (EntityPtr.IsValid())
                    {
                        FString EntityIDStr = EntityPtr->EntityID.ToString();
                        const FString* TagEntityIDPtr = EntityPtr->GetUnknownMetaTags().Find(TEXT("EntityID"));
                        FString TagEntityID = TagEntityIDPtr ? *TagEntityIDPtr : TEXT("");
                        if (EntityIDStr == TargetVesselStr || TagEntityID == TargetVesselStr || TagEntityID == CleanTargetVessel || TagEntityID == FString::Printf(TEXT("SIM_%s"), *CleanTargetVessel))
                        {
                            ResolvedVessel = EntityPtr->GetOwner();
                            UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Resolved target vessel [%s] via Priority 1 (EntityID/GUID match)."), *ResolvedVessel->GetName());
                            break;
                        }
                    }
                }

                // Priority 2: Exact Actor Name Match
                if (!ResolvedVessel)
                {
                    for (TWeakObjectPtr<USovereignSaveableEntityComponent>& EntityPtr : RegisteredSovereignEntities)
                    {
                        if (EntityPtr.IsValid() && EntityPtr->GetOwner())
                        {
                            AActor* Owner = EntityPtr->GetOwner();
                            if (Owner->GetName() == TargetVesselStr || Owner->GetName() == CleanTargetVessel)
                            {
                                ResolvedVessel = Owner;
                                UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Resolved target vessel [%s] via Priority 2 (Exact Name match)."), *ResolvedVessel->GetName());
                                break;
                            }
                        }
                    }
                }

                // Priority 3: Substring Match Fallback
                if (!ResolvedVessel)
                {
                    for (TWeakObjectPtr<USovereignSaveableEntityComponent>& EntityPtr : RegisteredSovereignEntities)
                    {
                        if (EntityPtr.IsValid() && EntityPtr->GetOwner())
                        {
                            AActor* Owner = EntityPtr->GetOwner();
                            if (Owner->GetName().Contains(CleanTargetVessel) || CleanTargetVessel.Contains(Owner->GetName()))
                            {
                                ResolvedVessel = Owner;
                                UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Resolved target vessel [%s] via Priority 3 (Substring Fallback match)."), *ResolvedVessel->GetName());
                                break;
                            }
                        }
                    }
                }
            }

            if (ResolvedVessel)
            {
                TargetAgent->PerformAgentPossession(ResolvedVessel);
                UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Dispatched PerformAgentPossession on Iron Knight Agent targeting [%s]."), *ResolvedVessel->GetName());
                return true;
            }
            else
            {
                UE_LOG(LogTemp, Error, TEXT("SovereignBridge: PerformAgentPossession failed - could not resolve target vessel [%s]."), *TargetVesselStr);
                return false;
            }
        }
        else if (ActionName == TEXT("EjectAgentPossession"))
        {
            TargetAgent->EjectAgentPossession();
            UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Dispatched EjectAgentPossession on Iron Knight Agent."));
            return true;
        }
    }

    // Spatial Movement & Interaction Directives (AD-035)
    if (ActionName == TEXT("MoveToLocation") || ActionName == TEXT("MoveToActor") || ActionName == TEXT("InteractWithObject"))
    {
        AActor* SubjectActor = nullptr;
        USovereignSaveableEntityComponent* SubjectSoul = nullptr;

        FString CleanTargetName = TargetName.Replace(TEXT("SIM_"), TEXT(""));

        // Priority 1: Exact Name / EntityID Match on Registered Entities
        for (TWeakObjectPtr<USovereignSaveableEntityComponent>& EntityPtr : RegisteredSovereignEntities)
        {
            if (EntityPtr.IsValid() && EntityPtr->GetOwner())
            {
                AActor* Owner = EntityPtr->GetOwner();
                const FString* TagIDPtr = EntityPtr->GetUnknownMetaTags().Find(TEXT("EntityID"));
                FString TagID = TagIDPtr ? *TagIDPtr : TEXT("");
                if (Owner->GetName() == TargetName || Owner->GetName() == CleanTargetName || TagID == TargetName || TagID == CleanTargetName)
                {
                    SubjectActor = Owner;
                    SubjectSoul = EntityPtr.Get();
                    break;
                }
            }
        }

        // Priority 2: Substring Match Fallback
        if (!SubjectActor)
        {
            for (TWeakObjectPtr<USovereignSaveableEntityComponent>& EntityPtr : RegisteredSovereignEntities)
            {
                if (EntityPtr.IsValid() && EntityPtr->GetOwner())
                {
                    AActor* Owner = EntityPtr->GetOwner();
                    if (Owner->GetName().Contains(CleanTargetName) || CleanTargetName.Contains(Owner->GetName()))
                    {
                        SubjectActor = Owner;
                        SubjectSoul = EntityPtr.Get();
                        break;
                    }
                }
            }
        }

        if (!SubjectActor)
        {
            UE_LOG(LogTemp, Error, TEXT("SovereignBridge: Directive [%s] failed - Subject actor [%s] not found."), *ActionName, *TargetName);
            return false;
        }

        // If SubjectActor is Iron Knight Agent and currently possessing a vessel, redirect movement to the possessed vessel
        if (ASovereignIronKnightAgent* Agent = Cast<ASovereignIronKnightAgent>(SubjectActor))
        {
            if (Agent->bIsPossessingTarget && Agent->PossessedTargetActor)
            {
                UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Agent [%s] is possessing vessel [%s]. Redirecting movement directive to possessed vessel."),
                    *SubjectActor->GetName(), *Agent->PossessedTargetActor->GetName());
                SubjectActor = Agent->PossessedTargetActor;
                SubjectSoul = SubjectActor->FindComponentByClass<USovereignSaveableEntityComponent>();
            }
        }

        // Option C Guard: Verify bIsMobile for Movement Directives (AD-035)
        if (ActionName == TEXT("MoveToLocation") || ActionName == TEXT("MoveToActor"))
        {
            if (SubjectSoul && !SubjectSoul->bIsMobile)
            {
                UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Movement Directive [%s] REJECTED - Subject actor [%s] has bIsMobile=false (Static Entity Guard)."),
                    *ActionName, *SubjectActor->GetName());
                return false;
            }

            FVector TargetDestination = FVector::ZeroVector;
            bool bHasDestination = false;

            // Check for target_vessel or target_actor in Params JSON
            TSharedPtr<FJsonObject> ParamsJsonObj;
            if (!ParamsJsonStr.IsEmpty())
            {
                TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ParamsJsonStr);
                FJsonSerializer::Deserialize(Reader, ParamsJsonObj);
            }

            FString DestinationTargetStr;
            if (ParamsJsonObj.IsValid())
            {
                if (ParamsJsonObj->HasField(TEXT("target_vessel"))) DestinationTargetStr = ParamsJsonObj->GetStringField(TEXT("target_vessel"));
                else if (ParamsJsonObj->HasField(TEXT("target_actor"))) DestinationTargetStr = ParamsJsonObj->GetStringField(TEXT("target_actor"));
            }

            if (!DestinationTargetStr.IsEmpty())
            {
                FString CleanDest = DestinationTargetStr.Replace(TEXT("SIM_"), TEXT(""));
                for (TWeakObjectPtr<USovereignSaveableEntityComponent>& EntityPtr : RegisteredSovereignEntities)
                {
                    if (EntityPtr.IsValid() && EntityPtr->GetOwner())
                    {
                        AActor* DestOwner = EntityPtr->GetOwner();
                        const FString* TagIDPtr = EntityPtr->GetUnknownMetaTags().Find(TEXT("EntityID"));
                        FString TagID = TagIDPtr ? *TagIDPtr : TEXT("");
                        if (DestOwner->GetName() == DestinationTargetStr || DestOwner->GetName() == CleanDest || DestOwner->GetName().Contains(CleanDest) || TagID == DestinationTargetStr || TagID == CleanDest)
                        {
                            TargetDestination = DestOwner->GetActorLocation();
                            bHasDestination = true;
                            UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Movement target resolved to Actor [%s] at Location %s"), *DestOwner->GetName(), *TargetDestination.ToString());
                            break;
                        }
                    }
                }
            }

            // Check for explicit Vector coordinates in Params JSON {"location": {"X": 100, "Y": 200, "Z": 0}}
            if (!bHasDestination && ParamsJsonObj.IsValid())
            {
                TSharedPtr<FJsonObject> LocObj;
                if (ParamsJsonObj->HasField(TEXT("location")))
                {
                    LocObj = ParamsJsonObj->GetObjectField(TEXT("location"));
                }
                else
                {
                    LocObj = ParamsJsonObj;
                }

                if (LocObj.IsValid() && (LocObj->HasField(TEXT("X")) || LocObj->HasField(TEXT("x"))))
                {
                    double X = LocObj->HasField(TEXT("X")) ? LocObj->GetNumberField(TEXT("X")) : LocObj->GetNumberField(TEXT("x"));
                    double Y = LocObj->HasField(TEXT("Y")) ? LocObj->GetNumberField(TEXT("Y")) : LocObj->GetNumberField(TEXT("y"));
                    double Z = LocObj->HasField(TEXT("Z")) ? LocObj->GetNumberField(TEXT("Z")) : LocObj->GetNumberField(TEXT("z"));
                    TargetDestination = FVector(X, Y, Z);
                    bHasDestination = true;
                    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Movement target resolved to Vector Location %s"), *TargetDestination.ToString());
                }
            }

            if (bHasDestination)
            {
                // Project 3D coordinate (e.g. Z=400) onto the nearest floor NavMesh surface
                if (UWorld* World = GetWorld())
                {
                    if (UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(World))
                    {
                        FNavLocation ProjectedNavLoc;
                        if (NavSys->ProjectPointToNavigation(TargetDestination, ProjectedNavLoc, FVector(500.0f, 500.0f, 1000.0f)))
                        {
                            UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Projected 3D target %s to NavMesh floor location %s"),
                                *TargetDestination.ToString(), *ProjectedNavLoc.Location.ToString());
                            TargetDestination = ProjectedNavLoc.Location;
                        }
                    }
                }

                // Micro-Execution via local AIController NavMesh pathfinding
                APawn* SubjectPawn = Cast<APawn>(SubjectActor);
                if (SubjectPawn)
                {
                    AController* Controller = SubjectPawn->GetController();
                    if (!Controller)
                    {
                        SubjectPawn->SpawnDefaultController();
                        Controller = SubjectPawn->GetController();
                    }

                    AAIController* AIController = Cast<AAIController>(Controller);
                    if (AIController)
                    {
                        if (AIController->GetPawn() != SubjectPawn)
                        {
                            AIController->Possess(SubjectPawn);
                        }

                        bool bIsCharacter = SubjectPawn->IsA<ACharacter>();
                        // Ground ACharacter uses NavMesh pathfinding (bUsePathfinding = true).
                        // 3D Floating Pawns (e.g. ASovereignIronKnightAgent) use direct 3D vector navigation (bUsePathfinding = false).
                        bool bUsePathfinding = bIsCharacter;

                        EPathFollowingRequestResult::Type MoveResult = AIController->MoveToLocation(TargetDestination, 50.0f, true, bUsePathfinding, bIsCharacter, true, nullptr, true);

                        UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Executed AAIController::MoveToLocation on [%s] (IsCharacter: %s, UsePathfinding: %s) targeting %s (Result: %d)"),
                            *SubjectActor->GetName(), bIsCharacter ? TEXT("True") : TEXT("False"), bUsePathfinding ? TEXT("True") : TEXT("False"), *TargetDestination.ToString(), (int32)MoveResult);
                        return true;
                    }
                }

                // Fallback location update if no controller is present
                SubjectActor->SetActorLocation(TargetDestination, false, nullptr, ETeleportType::TeleportPhysics);
                UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Direct location update on [%s] targeting %s"), *SubjectActor->GetName(), *TargetDestination.ToString());
                return true;
            }
            else
            {
                UE_LOG(LogTemp, Error, TEXT("SovereignBridge: MoveTo directive failed - Could not resolve target location or destination actor."));
                return false;
            }
        }
        else if (ActionName == TEXT("InteractWithObject"))
        {
            AActor* InteractTarget = nullptr;

            TSharedPtr<FJsonObject> ParamsJsonObj;
            if (!ParamsJsonStr.IsEmpty())
            {
                TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ParamsJsonStr);
                FJsonSerializer::Deserialize(Reader, ParamsJsonObj);
            }

            FString InteractTargetStr;
            if (ParamsJsonObj.IsValid())
            {
                if (ParamsJsonObj->HasField(TEXT("target_object"))) InteractTargetStr = ParamsJsonObj->GetStringField(TEXT("target_object"));
                else if (ParamsJsonObj->HasField(TEXT("target_vessel"))) InteractTargetStr = ParamsJsonObj->GetStringField(TEXT("target_vessel"));
                else if (ParamsJsonObj->HasField(TEXT("target_actor"))) InteractTargetStr = ParamsJsonObj->GetStringField(TEXT("target_actor"));
            }

            if (!InteractTargetStr.IsEmpty())
            {
                FString CleanInteract = InteractTargetStr.Replace(TEXT("SIM_"), TEXT(""));
                for (TWeakObjectPtr<USovereignSaveableEntityComponent>& EntityPtr : RegisteredSovereignEntities)
                {
                    if (EntityPtr.IsValid() && EntityPtr->GetOwner())
                    {
                        AActor* Owner = EntityPtr->GetOwner();
                        if (Owner->GetName() == InteractTargetStr || Owner->GetName() == CleanInteract || Owner->GetName().Contains(CleanInteract))
                        {
                            InteractTarget = Owner;
                            break;
                        }
                    }
                }
            }

            if (InteractTarget)
            {
                if (InteractTarget->GetClass()->ImplementsInterface(UInteractionInterface::StaticClass()))
                {
                    IInteractionInterface::Execute_OnInteract(InteractTarget, SubjectActor);
                    UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Dispatched InteractWithObject (InteractionInterface) from [%s] targeting [%s]."), *SubjectActor->GetName(), *InteractTarget->GetName());
                    return true;
                }
            }
        }
    }

    return false;
}

void USovereignBridgeSubsystem::StartDirectivePolling(const FString& ActorName)
{
    if (ActorName.StartsWith(TEXT("SIM_")))
    {
        DirectiveActorName = ActorName;
    }
    else
    {
        DirectiveActorName = FString::Printf(TEXT("SIM_%s"), *ActorName);
    }

    StopDirectivePolling();

    UWorld* World = GetWorld();
    if (World)
    {
        World->GetTimerManager().SetTimer(
            DirectiveTimerHandle,
            this,
            &USovereignBridgeSubsystem::QueryDirectives,
            2.0f,
            true
        );
        UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Control Plane Directive Polling started for [%s]."), *DirectiveActorName);
    }
}

void USovereignBridgeSubsystem::StopDirectivePolling()
{
    UWorld* World = GetWorld();
    if (World)
    {
        World->GetTimerManager().ClearTimer(DirectiveTimerHandle);
    }

    TSharedPtr<IHttpRequest, ESPMode::ThreadSafe> RequestPtr = ActiveDirectiveRequest.Pin();
    if (RequestPtr.IsValid())
    {
        RequestPtr->CancelRequest();
    }
}

void USovereignBridgeSubsystem::QueryDirectives()
{
    if (DirectiveActorName.IsEmpty()) return;

    TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = FHttpModule::Get().CreateRequest();
    Request->OnProcessRequestComplete().BindUObject(this, &USovereignBridgeSubsystem::OnDirectivesResponse);

    ActiveDirectiveRequest = Request;

    FString TargetURL = BridgeBaseUrl + TEXT("/v1/unreal/directives/poll?actor_name=") + DirectiveActorName;
    Request->SetURL(TargetURL);
    Request->SetVerb(TEXT("GET"));
    Request->ProcessRequest();
}

void USovereignBridgeSubsystem::OnDirectivesResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
    if (bWasSuccessful && Response.IsValid() && EHttpResponseCodes::IsOk(Response->GetResponseCode()))
    {
        TSharedPtr<FJsonObject> JsonObject;
        TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Response->GetContentAsString());

        if (FJsonSerializer::Deserialize(Reader, JsonObject) && JsonObject.IsValid())
        {
            const TArray<TSharedPtr<FJsonValue>>* DirectivesArray;
            if (JsonObject->TryGetArrayField(TEXT("directives"), DirectivesArray))
            {
                for (const TSharedPtr<FJsonValue>& DirVal : *DirectivesArray)
                {
                    TSharedPtr<FJsonObject> DirObj = DirVal->AsObject();
                    if (DirObj.IsValid())
                    {
                        FSovereignDirective Directive;
                        Directive.SenderID = DirObj->GetStringField(TEXT("sender_id"));
                        Directive.TargetEntity = DirObj->GetStringField(TEXT("target_entity"));
                        Directive.ActionName = DirObj->GetStringField(TEXT("action_name"));

                        TSharedPtr<FJsonObject> ParamsObj = DirObj->GetObjectField(TEXT("parameters"));
                        if (ParamsObj.IsValid())
                        {
                            FString OutputParams;
                            TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&OutputParams);
                            FJsonSerializer::Serialize(ParamsObj.ToSharedRef(), Writer);
                            Directive.ParametersJson = OutputParams;
                        }

                        Directive.AuthorityToken = DirObj->GetStringField(TEXT("authority_token"));

                        UE_LOG(LogTemp, Warning, TEXT("SovereignBridge: Control Plane Directive Received: %s -> %s (%s)"),
                            *Directive.SenderID, *Directive.TargetEntity, *Directive.ActionName);

                        // Construct legacy format for ProcessRuntimeDirective dispatch
                        FString FormattedMsg = FString::Printf(TEXT("[DIRECTIVE:%s] sender=%s target=%s params=%s"),
                            *Directive.ActionName, *Directive.SenderID, *Directive.TargetEntity, *Directive.ParametersJson);

                        ProcessRuntimeDirective(FormattedMsg);
                        OnDirectiveReceived.Broadcast(Directive);
                    }
                }
            }
        }
    }
}
